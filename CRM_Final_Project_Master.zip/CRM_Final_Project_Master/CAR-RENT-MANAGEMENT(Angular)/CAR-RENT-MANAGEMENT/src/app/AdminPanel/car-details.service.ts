import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Car } from './car-details/car';
import { Subject, Observable } from 'rxjs';
import { tap } from 'rxjs/operators';


const headerOption = {
  headers: new HttpHeaders({
    'content-type': 'application/json'
  })
};

@Injectable()
export class CarDetailsService {
  private baseUrl = 'http://localhost:8084/Car_Rent_Management/api/v1/cardetails';

  cardetails: Car = {
    carid : null,
    catid : null,
    brand : '',
    rantprice:null,
    image:'',
    colour:'',
    fuel:'',
    mileage:'',
    carcategory:'',
    status:true,
  };

  constructor(private http: HttpClient) {}

  private _refreshNeeded$ = new Subject<void>();

  get refreshNeeded$() {
    return this._refreshNeeded$;
  }

  getAllCarDetails(): Observable<Car[]> {
    return this.http.get<Car[]>(this.baseUrl, headerOption);
  }

  createCar(car: Car): Observable<Car> {
    return this.http.post<Car>(this.baseUrl, car, headerOption).pipe(
      tap(() => {
        this._refreshNeeded$.next();
      })
    );
  }

  updateCar(car: Car): Observable<Car> {
    return this.http
      .put<Car>(this.baseUrl + '/' + car.carid, car)
      .pipe(
        tap(() => {
          this._refreshNeeded$.next();
        })
      );
  }

  deleteCar(carid: number): Observable<Car> {
    return this.http.delete<Car>(this.baseUrl + '/' + carid);
  }

  getCarById(carid: number): Observable<Car> {
    return this.http.get<Car>(this.baseUrl + '/' + carid, headerOption);
  }
}
