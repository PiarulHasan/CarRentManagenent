import { Component, OnInit, HostListener } from '@angular/core';
import { CarDetailsService } from '../car-details.service';
import { Car } from './car';
import { DataSource } from '@angular/cdk/collections';
import { MatTableDataSource } from '@angular/material';

@Component({
  selector: 'app-car-details',
  templateUrl: './car-details.component.html',
  styleUrls: ['./car-details.component.css']
})
export class CarDetailsComponent implements OnInit {

  cardetails: Car[];
  dataSource: any;
  searchText="";
  constructor(public carDetailService: CarDetailsService) {

    this.getAllPackage();
    this.carDetailService.refreshNeeded$.subscribe(() => {
      this.getAllPackage();
    });
    this.getAllPackage();
  }


  ngOnInit() {
  }

  createOrUpdate(currentCar: Car) {
    if (currentCar.carid != null) {
      this.updateCar(currentCar);
    } else {
      this.createCar(currentCar);
    }
  }

  updateCar(currentCar: Car) {
    this.carDetailService.updateCar(currentCar).subscribe();
  }

  createCar(currentCar: Car) {
    this.carDetailService.createCar(currentCar).subscribe();
    this.ngOnInit();
  }

  clear() {
    this.carDetailService.cardetails = {
      carid: null,
      catid: null,
      brand: '',
      rantprice: null,
      image: '',
      colour: '',
      fuel: '',
      mileage: '',
      carcategory: '',
      status: true,
    };
  }
  getAllPackage() {
    this.carDetailService.getAllCarDetails().subscribe((data: Car[]) => {
      this.cardetails = data;
    });
  }

  deletePack(tpackid: number) {
    this.carDetailService.deleteCar(tpackid).subscribe((data: Car) => {
      this.getAllPackage();
    });
  }

  editPack(pc: Car) {
    this.carDetailService.cardetails = Object.assign({}, pc);

  } 
  
}
// export class TableFilteringExample {
//   displayedColumns: string[] = ['position', 'name', 'weight', 'symbol'];
//   dataSource = new MatTableDataSource(cardetails);
  

//   applyFilter(event: Event) {
//     const filterValue = (event.target as HTMLInputElement).value;
//     this.dataSource.filter = filterValue.trim().toLowerCase();
//   }
// }