import { CarDetailsModule } from './car-details.module';

describe('CarDetailsModule', () => {
  let carDetailsModule: CarDetailsModule;

  beforeEach(() => {
    carDetailsModule = new CarDetailsModule();
  });

  it('should create an instance', () => {
    expect(carDetailsModule).toBeTruthy();
  });
});
