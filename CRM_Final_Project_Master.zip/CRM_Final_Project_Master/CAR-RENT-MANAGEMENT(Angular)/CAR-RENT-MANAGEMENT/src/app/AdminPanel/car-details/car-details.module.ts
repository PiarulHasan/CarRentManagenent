import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CarDetailsComponent } from './car-details.component';
import { CarDetailsService } from '../car-details.service';
import { SharedModule } from 'src/app/shared/shared.module';
import { MatFormFieldModule, MatInputModule,MatSelectModule } from '@angular/material';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    HttpClientModule,
    BrowserModule,
    FormsModule
  ],
  declarations: [CarDetailsComponent],
  providers: [CarDetailsService]
})
export class CarDetailsModule { }
