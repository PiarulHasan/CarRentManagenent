export class Car{
    carid : number;
    catid : number;
    brand : string;
    rantprice:number;
    image:string;
    colour:string;
    fuel:string;
    mileage:string;
    carcategory:string;
    status:boolean;
}