import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-car-report',
  templateUrl: './car-report.component.html',
  styleUrls: ['./car-report.component.css']
})
export class CarReportComponent implements OnInit {

  carname: string;

  src="";

  constructor() { }

  ngOnInit(): void {
  }

  generateAllpurchaseReport(){
    
      
    this.src = "http://localhost:8084/Car_Rent_Management/reportView/"+this.carname;
    console.log(this.src);

}

clear(){
  this.carname ="";

}

}
