import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DefaultComponent } from "./AdminPanel/default/default.component";
import { DashboardComponent } from './modules/dashboard/dashboard.component';
import { PostsComponent } from './modules/posts/posts.component';
import { CarDetailsComponent } from './AdminPanel/car-details/car-details.component';
import { MatFormFieldModule } from '@angular/material';
import { CarDriverComponent } from './car-driver/car-driver.component';
import { CategoryComponent } from './category/category.component';
import { CarcompanyComponent } from './carcompany/carcompany.component';
import { CompanyPaymentComponent } from './company-payment/company-payment.component';
import { DriverPaymentComponent } from './driver-payment/driver-payment.component';
import { BodyComponent } from './body/body.component';
import { CartComponent } from './cart/cart.component';
import { CartdetailComponent } from './cart/cartdetail/cartdetail.component';
import { CustomerComponent } from './customer/customer.component';
import { BookingComponent } from './booking/booking.component';
import { BookingcartComponent } from './cart/bookingcart/bookingcart.component';
import { CarReportComponent } from './Report/car-report/car-report.component';


const routes: Routes = [{
    path: 'admin',
    component: DefaultComponent,
    children: [{
        path: '',
        component: DashboardComponent
    },
    {
        path:'posts',
        component:PostsComponent
    },
    {
        path:'cardetails',
        component:CarDetailsComponent
    },
    {
        path:'companypayment',
        component:CompanyPaymentComponent
    },
    {
        path:'cardriver',
        component:CarDriverComponent
    },
    {
        path:'category',
        component:CategoryComponent
    },
    {
        path:'carcompany',
        component:CarcompanyComponent
    },
    {
        path:'driverpayment',
        component:DriverPaymentComponent
    },
    {
        path:'booking',
        component:BookingComponent
    },
    {
        path:'customer',
        component:CustomerComponent
    },
    {
        path:"carreport",
        component: CarReportComponent
    }
    

]

},
{
    path:'',
    component:BodyComponent,
    children:[
    {
        path:'',
        component:CartComponent
    }, 
    {
        path:'cartdetail',
        component:CartdetailComponent
    },
    {
        path:'regcustomer',
        component:BookingcartComponent
    }
    ]
},

{ path: 'cardetails', component: CarDetailsComponent },
{ path: 'cardriver', component: CarDriverComponent },
{ path: 'category', component: CategoryComponent },
{ path: 'carcompany', component: CarcompanyComponent},
{ path: 'companypayment', component: CompanyPaymentComponent},
{ path: 'driverpayment', component: DriverPaymentComponent},
{ path: 'cart', component: CartComponent},
{ path: 'customer', component: CustomerComponent},
{ path: 'booking', component: BookingComponent}

];


@NgModule({
    imports: [RouterModule.forRoot(routes), MatFormFieldModule],
    exports: [RouterModule]
})
export class AppRoutingModule { }