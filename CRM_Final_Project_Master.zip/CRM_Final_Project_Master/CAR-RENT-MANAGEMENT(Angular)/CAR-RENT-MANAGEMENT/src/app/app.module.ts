import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {MatFormFieldModule} from '@angular/material/form-field';

import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DefaultModule } from './AdminPanel/default/default.module';
import { AppRoutingModule } from './app-routing.module';
import { CarDetailsComponent } from './AdminPanel/car-details/car-details.component';
import { CarDetailsModule } from './AdminPanel/car-details/car-details.module';
import { HttpClientModule } from '@angular/common/http';
import { MatSelectModule, MatInputModule, MatCardModule } from '@angular/material';
import { FormsModule } from '@angular/forms';
import { CarDriverComponent } from './car-driver/car-driver.component';
import { CarDriverModule } from './car-driver/car-driver.module';
import { CategoryComponent } from './category/category.component';
import { CarcompanyComponent } from './carcompany/carcompany.component';
import { CompanyPaymentComponent } from './company-payment/company-payment.component';
import { DriverPaymentComponent } from './driver-payment/driver-payment.component';
import { BodyComponent } from './body/body.component';
import { CartComponent } from './cart/cart.component';
import { CarCart } from './cart/Cartmodel/cart.model';
import { CartSummaryComponent } from './cart/cart-summary/cart-summary.component';
import { CartdetailComponent } from './cart/cartdetail/cartdetail.component';
import { RouterModule } from '@angular/router';
import { CustomerComponent } from './customer/customer.component';
import { BookingComponent } from './booking/booking.component';
import { BookingcartComponent } from './cart/bookingcart/bookingcart.component';
import { ConfirmcartComponent } from './cart/confirmcart/confirmcart.component';
import { CarReportComponent } from './Report/car-report/car-report.component';

import { PdfViewerModule } from 'ng2-pdf-viewer';




@NgModule({
  declarations: [
    AppComponent,
    CarDriverComponent,
    CategoryComponent,
    CarcompanyComponent,
    CompanyPaymentComponent,
    DriverPaymentComponent,
    BodyComponent,
    CartComponent,
    CartSummaryComponent,
    CartdetailComponent,
    CustomerComponent,
    BookingComponent,
    BookingcartComponent,
    ConfirmcartComponent,
    CarReportComponent,
  
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    DefaultModule,
    CarDetailsModule,
    HttpClientModule,
    MatInputModule,
    FormsModule,
    MatFormFieldModule,
    MatSelectModule,
    MatCardModule,
    RouterModule,
    PdfViewerModule
  ],
  providers: [
    CarCart
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
