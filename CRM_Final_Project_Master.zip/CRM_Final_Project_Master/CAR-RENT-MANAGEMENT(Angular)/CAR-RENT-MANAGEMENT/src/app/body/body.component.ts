import { Component, OnInit } from '@angular/core';
import { CarDetailsComponent } from '../AdminPanel/car-details/car-details.component';
import { CarDetailsService } from '../AdminPanel/car-details.service';
import { Car } from '../AdminPanel/car-details/car';

@Component({
  selector: 'app-body',
  templateUrl: './body.component.html',
  styleUrls: ['./body.component.css']
})
export class BodyComponent implements OnInit {

  constructor(private carDetailService: CarDetailsService,) { }

  
  cardetails: Car[];

  

  

  ngOnInit(): void {
    this.getAllCarDetails();
    
  }

  getAllCarDetails(){
    this.carDetailService.getAllCarDetails().subscribe(
      (data: Car[]) => {
        this.cardetails = data;
      }
    );
  }

  // getAllCategories(){
  //   this.categoryservice.getAllCategory().subscribe(
  //     (data: Category[]) => {
  //       this.allprocat = data;
  //     }
  //   );
  // }
}
