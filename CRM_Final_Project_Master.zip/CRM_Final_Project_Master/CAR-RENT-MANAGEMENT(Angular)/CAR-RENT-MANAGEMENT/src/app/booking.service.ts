import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Booking } from './booking/booking';
import { Subject, Observable } from 'rxjs';
import { tap } from 'rxjs/operators';



const headerOption = {
  headers: new HttpHeaders({
    'content-type': 'application/json'
  })
};


@Injectable({
  providedIn: 'root'
})
export class BookingService {
  private baseUrl = 'http://localhost:8084/Car_Rent_Management/api/v1/booking';

  booking: Booking =  new Booking( null, "", null, null, null, null, "", null);

  constructor(private http: HttpClient) { }

  private _refreshNeeded$ = new Subject<void>();

  get refreshNeeded$() {
    return this._refreshNeeded$;
  }

  getAllBooking(): Observable<Booking[]> {
    return this.http.get<Booking[]>(this.baseUrl, headerOption);
  }

  createBooking(booking: Booking): Observable<Booking> {
    return this.http.post<Booking>(this.baseUrl, booking, headerOption).pipe(
      tap(() => {
        this._refreshNeeded$.next();
      })
    );
  }

  updateBooking(booking: Booking): Observable<Booking> {
    return this.http
      .put<Booking>(this.baseUrl + '/' + booking.bookingid, booking)
      .pipe(
        tap(() => {
          this._refreshNeeded$.next();
        })
      );
  }

  deleteBooking(bookingid: number): Observable<Booking> {
    return this.http.delete<Booking>(this.baseUrl + '/' + bookingid);
  }

  getBookingById(bookingid: number): Observable<Booking> {
    return this.http.get<Booking>(this.baseUrl + '/' + bookingid, headerOption);
  }
  

}
