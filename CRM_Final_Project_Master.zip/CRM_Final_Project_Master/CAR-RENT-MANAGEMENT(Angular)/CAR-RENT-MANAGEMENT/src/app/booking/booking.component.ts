import { Component, OnInit } from '@angular/core';
import { Booking } from './booking';
import { BookingService } from '../booking.service';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {

  booking: Booking[];

  constructor(public bookingService: BookingService) {
  }


  ngOnInit() {
    this.getAllPackage();
    this.bookingService.refreshNeeded$.subscribe(() => {
      this.getAllPackage();
    });
  }

  updateBooking(currentBooking: Booking) {
    this.bookingService.updateBooking(currentBooking).subscribe();
  }

  createBooking(currentBooking: Booking) {
    this.bookingService.createBooking(currentBooking).subscribe();
    this.ngOnInit();
  }

  clear() {
    this.bookingService.booking = new Booking( null, "", null, null, null, null, "", null);
  }

  getAllPackage() {
    this.bookingService.getAllBooking().subscribe((data: Booking[]) => {
      this.booking = data;
    });
  }

  deletePack(tpackid: number) {
    this.bookingService.deleteBooking(tpackid).subscribe();
  }

  editPack(pc: Booking) {
    this.bookingService.booking = Object.assign({}, pc);

  }

}
