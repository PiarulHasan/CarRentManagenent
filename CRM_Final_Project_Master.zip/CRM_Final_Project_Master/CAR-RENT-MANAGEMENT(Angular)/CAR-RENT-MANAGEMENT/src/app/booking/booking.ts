export class Booking{
    bookingid : number;
    carid : number;
    carname : string;
    date : Date;
    days : number;
    price : number;
    subtotal : number;
    ststus : string;
    custid: number;

    constructor(public scarid, public scarname, public sdate, public sdays, public sprice, public ssubtotal, public status, public scustid){
        this.scarid = null;
        this.scarname = "";
        this.sdate = null;
        this. sdays = null;
        this. sprice = null;
        this.ssubtotal = null;
        this.status = "";
        this.scustid = null;
    }
}