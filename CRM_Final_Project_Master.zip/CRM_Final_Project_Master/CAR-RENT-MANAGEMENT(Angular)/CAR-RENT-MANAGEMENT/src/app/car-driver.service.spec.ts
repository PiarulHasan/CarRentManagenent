import { TestBed } from '@angular/core/testing';

import { CarDriverService } from './car-driver.service';

describe('CarDriverService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CarDriverService = TestBed.get(CarDriverService);
    expect(service).toBeTruthy();
  });
});
