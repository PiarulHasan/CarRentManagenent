import { Injectable } from '@angular/core';
import { from, Subject, Observable } from 'rxjs';
import { Driver } from './car-driver/driver';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';


const headerOption = {
  headers: new HttpHeaders({
    'content-type': 'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class CarDriverService {
  private baseUrl = 'http://localhost:8084/Car_Rent_Management/api/v1/cardriver';
  
  cardriver: Driver = {
    driverid : null,
    name : '',
    address : '',
    phone : '',
    email : '',
    licenseno : '',
    expyear : '',
    location : '',    
    status : true,
  }

  constructor(private http: HttpClient) { }

  private _refreshNeeded$ = new Subject<void>();

  get refreshNeeded$() {
    return this._refreshNeeded$;
  }

  getAllDriver(): Observable<Driver[]> {
    return this.http.get<Driver[]>(this.baseUrl, headerOption);
  }

  createDriver(driver: Driver): Observable<Driver> {
    return this.http.post<Driver>(this.baseUrl, driver, headerOption).pipe(
      tap(() => {
        this._refreshNeeded$.next();
      })
    );
  }

  updateDriver(driver: Driver): Observable<Driver> {
    return this.http
      .put<Driver>(this.baseUrl + '/' + driver.driverid, driver)
      .pipe(
        tap(() => {
          this._refreshNeeded$.next();
        })
      );
  }

  deleteCarDriver(driverid: number): Observable<Driver> {
    return this.http.delete<Driver>(this.baseUrl + '/' + driverid);
  }

  getCarDriverById(driverid: number): Observable<Driver> {
    return this.http.get<Driver>(this.baseUrl + '/' + driverid, headerOption);
  }
}
