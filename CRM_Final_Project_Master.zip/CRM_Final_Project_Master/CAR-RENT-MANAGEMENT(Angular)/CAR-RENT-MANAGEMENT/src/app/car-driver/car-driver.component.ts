import { Component, OnInit } from '@angular/core';
import { CarDriverService } from '../car-driver.service';
import { Driver } from './driver';

@Component({
  selector: 'app-car-driver',
  templateUrl: './car-driver.component.html',
  styleUrls: ['./car-driver.component.css']
})
export class CarDriverComponent implements OnInit {

  cardriver: Driver[];
  constructor(public carDriverService:CarDriverService) {
    this.getAllPackage();
    this.carDriverService.refreshNeeded$.subscribe(() => {
      this.getAllPackage();
    });
    this.getAllPackage();
   }

  ngOnInit() {
  }

  createOrUpdate(currentDriver: Driver) {
    if (currentDriver.driverid != null) {
      this.updateDriver(currentDriver);
    } else {
      this.createDriver(currentDriver);
    }
  }

  updateDriver(currentDriver: Driver) {
    this.carDriverService.updateDriver(currentDriver).subscribe();
  }

  createDriver(currentDriver: Driver) {
    this.carDriverService.createDriver(currentDriver).subscribe();
    this.ngOnInit();
  }

  clear(){
    this.carDriverService.cardriver ={
    driverid : null,
    name : '',
    address : '',
    phone : '',
    email : '',
    licenseno : '',
    expyear : '',
    location : '',    
    status : true,
    }
  }

  getAllPackage() {
    this.carDriverService.getAllDriver().subscribe((data: Driver[]) => {
      this.cardriver = data;
    });
  }
  
  deletePack(tpackid: number) {
    this.carDriverService.deleteCarDriver(tpackid).subscribe((data: Driver) => {
      this.getAllPackage();
    });
  }
  
  editPack(pc: Driver) {
    this.carDriverService.cardriver = Object.assign({}, pc);
    
  }
}
