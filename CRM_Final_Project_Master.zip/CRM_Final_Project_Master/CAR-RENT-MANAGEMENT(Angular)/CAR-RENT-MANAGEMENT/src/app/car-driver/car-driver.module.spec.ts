import { CarDriverModule } from './car-driver.module';

describe('CarDriverModule', () => {
  let carDriverModule: CarDriverModule;

  beforeEach(() => {
    carDriverModule = new CarDriverModule();
  });

  it('should create an instance', () => {
    expect(carDriverModule).toBeTruthy();
  });
});
