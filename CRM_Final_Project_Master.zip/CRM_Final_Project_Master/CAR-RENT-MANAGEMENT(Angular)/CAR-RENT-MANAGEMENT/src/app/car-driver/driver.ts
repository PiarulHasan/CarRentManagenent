export class Driver{
    driverid : number;
    name : string;
    address : string;
    phone : string;
    email : string;
    licenseno : string;
    expyear : string;
    location : string;    
    status : boolean;
}