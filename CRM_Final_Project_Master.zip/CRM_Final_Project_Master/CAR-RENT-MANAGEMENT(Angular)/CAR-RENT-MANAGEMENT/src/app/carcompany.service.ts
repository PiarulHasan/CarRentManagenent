import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Carcompany } from './carcompany/carcompany';
import { Subject, Observable } from 'rxjs';
import { tap } from 'rxjs/operators';



const headerOption = {
  headers: new HttpHeaders({
    'content-type': 'application/json'
  })
};


@Injectable({
  providedIn: 'root'
})
export class CarcompanyService {
  private baseUrl = 'http://localhost:8084/Car_Rent_Management/api/v1/carcompany';

  carcompany: Carcompany = {
    companyid: null,
    catid: '',
    name: '',
    address: '',
    phone: '',
    price: null,
    email: '',
    date: new Date,
  }

  constructor(private http: HttpClient) { }

  private _refreshNeeded$ = new Subject<void>();

  get refreshNeeded$() {
    return this._refreshNeeded$;
  }

  getAllCarcompany(): Observable<Carcompany[]> {
    return this.http.get<Carcompany[]>(this.baseUrl, headerOption);
  }

  createCarcompany(carcompany: Carcompany): Observable<Carcompany> {
    return this.http.post<Carcompany>(this.baseUrl, carcompany, headerOption).pipe(
      tap(() => {
        this._refreshNeeded$.next();
      })
    );
  }

  updateCarcompany(carcompany: Carcompany): Observable<Carcompany> {
    return this.http
      .put<Carcompany>(this.baseUrl + '/' + carcompany.companyid, carcompany)
      .pipe(
        tap(() => {
          this._refreshNeeded$.next();
        })
      );
  }

  deleteCarcompany(companyid: number): Observable<Carcompany> {
    return this.http.delete<Carcompany>(this.baseUrl + '/' + companyid);
  }

  getCarcompanyById(companyid: number): Observable<Carcompany> {
    return this.http.get<Carcompany>(this.baseUrl + '/' + companyid, headerOption);
  }
}
