import { Component, OnInit } from '@angular/core';
import { Carcompany } from './carcompany';
import { CarcompanyService } from '../carcompany.service';

@Component({
  selector: 'app-carcompany',
  templateUrl: './carcompany.component.html',
  styleUrls: ['./carcompany.component.css']
})
export class CarcompanyComponent implements OnInit {

  carcompany: Carcompany[];
  constructor(public carcompanyService: CarcompanyService) {
    this.getAllPackage();
    this.carcompanyService.refreshNeeded$.subscribe(() => {
      this.getAllPackage();
    });
    this.getAllPackage();
   }

  ngOnInit() {
  }

  createOrUpdate(currentCarcompany: Carcompany) {
    if (currentCarcompany.companyid !=null) {
      this.updateCarcompany(currentCarcompany);
    } else {
      this.createCarcompany(currentCarcompany);
    }
  }

  updateCarcompany(currentCarcompany: Carcompany) {
    this.carcompanyService.updateCarcompany(currentCarcompany).subscribe();
  }

  createCarcompany(currentCarcompany: Carcompany) {
    this.carcompanyService.createCarcompany(currentCarcompany).subscribe();
    this.ngOnInit();
  }

  clear() {
    this.carcompanyService.carcompany = {
      companyid: null,
      catid: '',
      name: '',
      address: '',
      phone: '',
      price: null,
      email: '',
      date: null,
    };
  }

  getAllPackage() {
    this.carcompanyService.getAllCarcompany().subscribe((data: Carcompany[]) => {
      this.carcompany = data;
    });
  }
  
  deletePack(tpackid: number) {
    this.carcompanyService.deleteCarcompany(tpackid).subscribe((data: Carcompany) => {
      this.getAllPackage();
    });
  }
  
  editPack(pc: Carcompany) {
    this.carcompanyService.carcompany = Object.assign({}, pc);
    
  }

}
