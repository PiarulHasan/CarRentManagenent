import { CarcompanyModule } from './carcompany.module';

describe('CarcompanyModule', () => {
  let carcompanyModule: CarcompanyModule;

  beforeEach(() => {
    carcompanyModule = new CarcompanyModule();
  });

  it('should create an instance', () => {
    expect(carcompanyModule).toBeTruthy();
  });
});
