import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { MatFormFieldModule, MatInputModule, MatSelectModule, MatDatepicker, MatNativeDateModule, MatDatepickerModule } from '@angular/material';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { CarcompanyComponent } from './carcompany.component';
import { CarcompanyService } from '../carcompany.service';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    HttpClientModule,
    BrowserModule,
    FormsModule
  ],
  declarations: [CarcompanyComponent],
  providers: [CarcompanyService]
})
export class CarcompanyModule { }
