export class Carcompany{
    companyid: number;
    catid: string;
    name: string;
    address: string;
    phone: string;
    price: number;
    email: string;
    date: Date;

}