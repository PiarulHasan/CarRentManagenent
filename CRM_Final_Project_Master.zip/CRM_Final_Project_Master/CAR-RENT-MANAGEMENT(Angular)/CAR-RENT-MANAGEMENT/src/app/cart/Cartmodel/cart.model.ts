import { Injectable } from "@angular/core";
import { Car } from "src/app/AdminPanel/car-details/car";

@Injectable()
export class CarCart {
    public lines: CartLine[] = [];
    public itemCount: number = 0;
    public cartPrice: number = 0;

    addLine(product: Car, day: number = 1) {
        let line = this.lines.find(line => line.product.carid == product.carid);
        if (line != undefined) {
            line.day += day;
        } else {
            this.lines.push(new CartLine(product, new Date(), day));
        }
        this.recalculate();
    }
    updateQuantity(product: Car, day: number) {
        let line = this.lines.find(line => line.product.carid == product.carid);
        if (line != undefined) {
            line.day = Number(day);
        }
        this.recalculate();
    }
    removeLine(id: number) {
        let index = this.lines.findIndex(line => line.product.carid == id);
        this.lines.splice(index, 1);
        this.recalculate();
    }
    clear() {
        this.lines = [];
        this.itemCount = 0;
        this.cartPrice = 0;
    }
    private recalculate() {
        this.itemCount = 0;
        this.cartPrice = 0;
        this.lines.forEach(l => {
            this.itemCount += l.day;
            this.cartPrice += (l.day * l.product.rantprice);
        })
    }
}
export class CartLine {
    constructor(public product: Car, public cdate: Date,
        public day: number) { }
    get lineTotal() {
        return this.day * this.product.rantprice;
    }
}