import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BookingcartComponent } from './bookingcart.component';

describe('BookingcartComponent', () => {
  let component: BookingcartComponent;
  let fixture: ComponentFixture<BookingcartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BookingcartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BookingcartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
