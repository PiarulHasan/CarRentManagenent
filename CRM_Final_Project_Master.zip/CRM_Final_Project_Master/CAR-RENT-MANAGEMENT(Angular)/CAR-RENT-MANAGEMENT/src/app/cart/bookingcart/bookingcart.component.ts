import { Component, OnInit } from '@angular/core';
import { CustomerService } from 'src/app/customer.service';
import { Customer } from 'src/app/customer/customer';

@Component({
  selector: 'app-bookingcart',
  templateUrl: './bookingcart.component.html',
  styleUrls: ['./bookingcart.component.css']
})
export class BookingcartComponent implements OnInit {

  msg="";

  constructor(
    public customerService: CustomerService
  ) { }

  ngOnInit() {
  }
  createCustomer(currentCustomer: Customer) {
    this.msg="Create successfully!!";
    this.customerService.createCustomer(currentCustomer).subscribe();
    this.ngOnInit();
  }

  clear() {
    this.customerService.customer = {
      custid: null,
      custname: '',
      address: '',
      phone: '',
      email: '',
      location: '',
      
    };
    this.msg=""
  }
  

}
