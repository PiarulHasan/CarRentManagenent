import { Component, OnInit } from '@angular/core';
import { CarDetailsService } from '../AdminPanel/car-details.service';
import { Car } from '../AdminPanel/car-details/car';
import { CarCart } from './Cartmodel/cart.model';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  constructor(private carDetailService: CarDetailsService, public cart: CarCart) { }

  cardetails: Car[];

  ngOnInit() {
    this.getAllCarDetails();
  }

  getAllCarDetails(){
    this.carDetailService.getAllCarDetails().subscribe(
      (data: Car[]) => {
        this.cardetails = data;
      }
    );
  }
  addCarToCart(product: Car) {
    this.cart.addLine(product);
    }

}
