import { Component, OnInit } from '@angular/core';
import { CarCart } from '../Cartmodel/cart.model';
import { Customer } from 'src/app/customer/customer';
import { CustomerService } from 'src/app/customer.service';
import { BookingService } from 'src/app/booking.service';
import { Booking } from 'src/app/booking/booking';

@Component({
  selector: 'app-cartdetail',
  templateUrl: './cartdetail.component.html',
  styleUrls: ['./cartdetail.component.css']
})
export class CartdetailComponent implements OnInit {

  allcustomer: Customer[];
  customerId: number;
  status = "pending";
  msg="";

  constructor(
    public cart: CarCart,
    public customerService: CustomerService,
    public bookingService: BookingService
  ) { }

  ngOnInit() {
    this.getAllPackage();
  }

  getAllPackage() {
    this.customerService.getAllCustomer().subscribe((data: Customer[]) => {
      this.allcustomer = data;
    });
  }


  DynamicBooking(cart: CarCart) {
    this.msg="Booking Successful!!"

    for (let i = 0; i < cart.lines.length; i++) {

      let bookingdetail: Booking = new Booking(
        cart.lines[i].product.carid,
        cart.lines[i].product.brand,
        cart.lines[i].cdate,
        cart.lines[i].day,
        cart.lines[i].product.rantprice,
        cart.lines[i].lineTotal,
        this.status,
        this.customerId
      );

      bookingdetail.carid = cart.lines[i].product.carid;
      bookingdetail.carname = cart.lines[i].product.brand;
      bookingdetail.date = cart.lines[i].cdate;
      bookingdetail.days =  cart.lines[i].day;
      bookingdetail.price = cart.lines[i].product.rantprice;
      bookingdetail.subtotal = cart.lines[i].lineTotal;
      bookingdetail.ststus = this.status;
      bookingdetail.custid = this.customerId;


      // this.createOrUpdateBranchsaledetail(this.branchsaledetailservice.newBranchsaleDetail[i]);
      //createOrUpdateBranchsaledetail(currentBranchsaledetail: Branchsaledetail) {

      if (bookingdetail.bookingid == null) {
        this.createBooking(bookingdetail);
      }

    }
    cart.clear();
  }


  createBooking(currentBooking: Booking) {
    this.bookingService.createBooking(currentBooking).subscribe();
    this.ngOnInit();
  }

}
