import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirmcart',
  templateUrl: './confirmcart.component.html',
  styleUrls: ['./confirmcart.component.css']
})
export class ConfirmcartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
