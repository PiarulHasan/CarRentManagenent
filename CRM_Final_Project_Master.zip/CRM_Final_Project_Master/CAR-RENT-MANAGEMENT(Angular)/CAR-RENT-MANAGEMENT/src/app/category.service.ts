import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Category } from './category/category';
import { Subject, Observable } from 'rxjs';
import { tap } from 'rxjs/operators';



const headerOption = {
  headers: new HttpHeaders({
    'content-type': 'application/json'
  })
};


@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  private baseUrl = 'http://localhost:8084/Car_Rent_Management/api/v1/category';

  category: Category ={
    catid : null,
    catname : '',
    description : '',
  }

  constructor(private http: HttpClient) { }

  private _refreshNeeded$ = new Subject<void>();

  get refreshNeeded$() {
    return this._refreshNeeded$;
  }

  getAllCategory(): Observable<Category[]> {
    return this.http.get<Category[]>(this.baseUrl, headerOption);
  }

  createCategory(category:Category):Observable<Category>{
    return this.http.post<Category>(this.baseUrl, category, headerOption).pipe(
      tap(() => {
        this._refreshNeeded$.next();
      })
    );
  }

 
  updateCategory(category: Category): Observable<Category> {
    return this.http
      .put<Category>(this.baseUrl + '/' + category.catid, category)
      .pipe(
        tap(() => {
          this._refreshNeeded$.next();
        })
      );
  }

  deleteCategory(catid: number): Observable<Category> {
    return this.http.delete<Category>(this.baseUrl + '/' + catid);
  }

  getCategoryById(catid: number): Observable<Category> {
    return this.http.get<Category>(this.baseUrl + '/' + catid, headerOption);
  }
}
