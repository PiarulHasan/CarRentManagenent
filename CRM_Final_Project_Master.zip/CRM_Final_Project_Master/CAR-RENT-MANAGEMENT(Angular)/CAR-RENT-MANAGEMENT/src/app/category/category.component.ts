import { Component, OnInit } from '@angular/core';
import { CategoryService } from '../category.service';
import { Category } from './category';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {
  
  category: Category[];
  constructor(public categoryService: CategoryService) {
    this.getAllPackage();
    this.categoryService.refreshNeeded$.subscribe(() => {
      this.getAllPackage();
    });
    this.getAllPackage();
   }

  ngOnInit() {
  }

  createOrUpdate(currentCategory: Category) {
    if (currentCategory.catid != null) {
      this.updateCategory(currentCategory);
    } else {
      this.createCategory(currentCategory);
    }
  }

  updateCategory(currentCategory: Category) {
    this.categoryService.updateCategory(currentCategory).subscribe();
  }

  createCategory(currentCategory: Category) {
    this.categoryService.createCategory(currentCategory).subscribe();
    this.ngOnInit();
  }

  clear() {
    this.categoryService.category = {    
    catid : null,
    catname : '',
    description : '',
    };
} 
getAllPackage() {
  this.categoryService.getAllCategory().subscribe((data: Category[]) => {
    this.category = data;
  });
}

deletePack(tpackid: number) {
  this.categoryService.deleteCategory(tpackid).subscribe((data: Category) => {
    this.getAllPackage();
  });
}

editPack(pc: Category) {
  this.categoryService.category = Object.assign({}, pc);
  
}

}
