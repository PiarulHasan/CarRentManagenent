export class Category{
    catid : number;
    catname : string;
    description : string;
}