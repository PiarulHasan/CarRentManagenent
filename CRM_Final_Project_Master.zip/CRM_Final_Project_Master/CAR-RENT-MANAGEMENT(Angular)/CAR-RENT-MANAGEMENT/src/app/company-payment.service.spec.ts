import { TestBed } from '@angular/core/testing';

import { CompanyPaymentService } from './company-payment.service';

describe('CompanyPaymentService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CompanyPaymentService = TestBed.get(CompanyPaymentService);
    expect(service).toBeTruthy();
  });
});
