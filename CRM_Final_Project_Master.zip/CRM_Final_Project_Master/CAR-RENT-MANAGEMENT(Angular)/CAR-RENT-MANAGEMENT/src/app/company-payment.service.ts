import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Companypayment } from './company-payment/company-payment';
import { Subject, Observable } from 'rxjs';
import { tap } from 'rxjs/operators';


const headerOption = {
  headers: new HttpHeaders({
    'content-type': 'application/json'
  })
};


@Injectable({
  providedIn: 'root'
})
export class CompanyPaymentService {
  private baseUrl = 'http://localhost:8084/Car_Rent_Management/api/v1/cpayment';

  companypayment: Companypayment ={
    paymentid : null,
    companyid : null,
    payamount : null,
    date : new Date,
  }

  constructor(private http: HttpClient) { }
  private _refreshNeeded$ = new Subject<void>();

  get refreshNeeded$() {
    return this._refreshNeeded$;
  }

  getAllCompanyPayment(): Observable<Companypayment[]> {
    return this.http.get<Companypayment[]>(this.baseUrl, headerOption);
  }

  createCompanyPayment(companypayment: Companypayment): Observable<Companypayment> {
    return this.http.post<Companypayment>(this.baseUrl, companypayment, headerOption).pipe(
      tap(() => {
        this._refreshNeeded$.next();
      })
    );
  }

  updateCompanyPayment(companypayment: Companypayment): Observable<Companypayment> {
    return this.http
      .put<Companypayment>(this.baseUrl + '/' + companypayment.paymentid, companypayment)
      .pipe(
        tap(() => {
          this._refreshNeeded$.next();
        })
      );
  }

  deleteCompanyPayment(paymentid: number): Observable<Companypayment> {
    return this.http.delete<Companypayment>(this.baseUrl + '/' + paymentid);
  }

  getCompanyPaymentById(paymentid: number): Observable<Companypayment> {
    return this.http.get<Companypayment>(this.baseUrl + '/' + paymentid, headerOption);
  }
}
