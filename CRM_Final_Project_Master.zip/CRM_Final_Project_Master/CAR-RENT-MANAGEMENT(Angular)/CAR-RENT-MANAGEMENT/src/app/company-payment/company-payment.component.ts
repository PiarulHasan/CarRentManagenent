import { Component, OnInit } from '@angular/core';
import { CompanyPaymentService } from '../company-payment.service';
import { Companypayment } from './company-payment';

@Component({
  selector: 'app-company-payment',
  templateUrl: './company-payment.component.html',
  styleUrls: ['./company-payment.component.css']
})
export class CompanyPaymentComponent implements OnInit {

  companyPayment: Companypayment[];
  constructor(public companyPaymentService : CompanyPaymentService) {
    
    this.getAllPackage();
    this.companyPaymentService.refreshNeeded$.subscribe(() => {
      this.getAllPackage();
    });
    this.getAllPackage();
   }

  ngOnInit() {
  }

  createOrUpdate(currentCompanypayment: Companypayment) {
    if (currentCompanypayment.paymentid != null) {
      this.updateCompanypayment(currentCompanypayment);
    } else {
      this.createCompanypayment(currentCompanypayment);
    }
  }

  updateCompanypayment(currentCompanypayment: Companypayment) {
    this.companyPaymentService.updateCompanyPayment(currentCompanypayment).subscribe();
  }

  createCompanypayment(currentCompanypayment: Companypayment) {
    this.companyPaymentService.createCompanyPayment(currentCompanypayment).subscribe();
    this.ngOnInit();
  }

  clear() {
    this.companyPaymentService.companypayment = {
    paymentid : null,
    companyid : null,
    payamount : null,
    date : new Date,
    
    };
}

getAllPackage() {
  this.companyPaymentService.getAllCompanyPayment().subscribe((data: Companypayment[]) => {
    this.companyPayment = data;
  });
}

deletePack(tpackid: number) {
  this.companyPaymentService.deleteCompanyPayment(tpackid).subscribe((data: Companypayment) => {
    this.getAllPackage();
  });
}

editPack(pc: Companypayment) {
  this.companyPaymentService.companypayment = Object.assign({}, pc);
}

}
