import { CompanyPaymentModule } from './company-payment.module';

describe('CompanyPaymentModule', () => {
  let companyPaymentModule: CompanyPaymentModule;

  beforeEach(() => {
    companyPaymentModule = new CompanyPaymentModule();
  });

  it('should create an instance', () => {
    expect(companyPaymentModule).toBeTruthy();
  });
});
