import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { MatFormFieldModule, MatInputModule, MatSelectModule } from '@angular/material';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { CompanyPaymentComponent } from './company-payment.component';
import { CompanyPaymentService } from '../company-payment.service';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    HttpClientModule,
    BrowserModule,
    FormsModule
  ],
  declarations: [CompanyPaymentComponent],
  providers:[CompanyPaymentService]
})
export class CompanyPaymentModule { }
