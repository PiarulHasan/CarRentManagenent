export class Companypayment{
paymentid : number;
companyid : number;
payamount : number;
date : Date;

}