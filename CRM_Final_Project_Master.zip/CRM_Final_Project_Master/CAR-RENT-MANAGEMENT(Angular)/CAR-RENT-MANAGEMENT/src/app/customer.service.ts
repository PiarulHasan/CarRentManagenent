import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Customer } from './customer/customer';
import { Subject, Observable } from 'rxjs';
import { tap } from 'rxjs/operators';



const headerOption = {
  headers: new HttpHeaders({
    'content-type': 'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  private baseUrl = 'http://localhost:8084/Car_Rent_Management/api/v1/customer';

  customer: Customer = {
    custid : null,
    custname : '',
    address : '',
    phone : '',
    email : '',
    location : '',
  }
  constructor(private http: HttpClient) { }

  private _refreshNeeded$ = new Subject<void>();

  get refreshNeeded$() {
    return this._refreshNeeded$;
  }

  getAllCustomer(): Observable<Customer[]> {
    return this.http.get<Customer[]>(this.baseUrl, headerOption);
  }

  createCustomer(customer: Customer): Observable<Customer> {
    return this.http.post<Customer>(this.baseUrl, customer, headerOption).pipe(
      tap(() => {
        this._refreshNeeded$.next();
      })
    );
  }

  updateCustomer(customer: Customer): Observable<Customer> {
    return this.http
      .put<Customer>(this.baseUrl + '/' + customer.custid, customer)
      .pipe(
        tap(() => {
          this._refreshNeeded$.next();
        })
      );
  }

  deleteCustomer(custid: number): Observable<Customer> {
    return this.http.delete<Customer>(this.baseUrl + '/' + custid);
  }

  getCustomerById(custid: number): Observable<Customer> {
    return this.http.get<Customer>(this.baseUrl + '/' + custid, headerOption);
  }

}
