import { Component, OnInit } from '@angular/core';
import { Customer } from './customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  customer: Customer[];
  constructor(public customerService: CustomerService) {
    
    
   }


  ngOnInit() {
    this.getAllPackage();
    this.customerService.refreshNeeded$.subscribe(() => {
      this.getAllPackage();
    });
    this.getAllPackage();
  }

  createOrUpdate(currentCustomer: Customer) {
    if (currentCustomer.custid != null) {
      this.updateCustomer(currentCustomer);
    } else {
      this.createCustomer(currentCustomer);
    }
  }

  updateCustomer(currentCustomer: Customer) {
    this.customerService.updateCustomer(currentCustomer).subscribe();
  }

  createCustomer(currentCustomer: Customer) {
    this.customerService.createCustomer(currentCustomer).subscribe();
    this.ngOnInit();
  }

  clear() {
    this.customerService.customer = {
      custid: null,
      custname: '',
      address: '',
      phone: '',
      email: '',
      location: '',
      
    };
  }
  getAllPackage() {
    this.customerService.getAllCustomer().subscribe((data: Customer[]) => {
      this.customer = data;
    });
  }

  deletePack(tpackid: number) {
    this.customerService.deleteCustomer(tpackid).subscribe((data: Customer) => {
      this.getAllPackage();
    });
  }

  editPack(pc: Customer) {
    this.customerService.customer = Object.assign({}, pc);

  }

}
