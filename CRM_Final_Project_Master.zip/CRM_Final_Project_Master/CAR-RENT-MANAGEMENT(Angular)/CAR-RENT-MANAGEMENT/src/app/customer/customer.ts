export class Customer{
    custid : number;
    custname : string;
    address : string;
    phone : string;
    email : string;
    location : string
}