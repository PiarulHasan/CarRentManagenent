import { TestBed } from '@angular/core/testing';

import { DriverPaymentService } from './driver-payment.service';

describe('DriverPaymentService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DriverPaymentService = TestBed.get(DriverPaymentService);
    expect(service).toBeTruthy();
  });
});
