import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Subject, Observable } from 'rxjs';
import { Driverpayment } from './driver-payment/driver-payment';
import { tap } from 'rxjs/operators';



const headerOption = {
  headers: new HttpHeaders({
    'content-type': 'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class DriverPaymentService {
  private baseUrl = 'http://localhost:8084/Car_Rent_Management/api/v1/dpayment';

  driverpayment: Driverpayment={
    paymentid : null,
    driverid : null,
    payamount : null,
    date : new Date,
  }

  constructor(private http: HttpClient) { }
  private _refreshNeeded$ = new Subject<void>();

  get refreshNeeded$() {
    return this._refreshNeeded$;
  }

  
  getAllDriverPayment(): Observable<Driverpayment[]> {
    return this.http.get<Driverpayment[]>(this.baseUrl, headerOption);
  }

  createDriverPayment(driverpayment: Driverpayment): Observable<Driverpayment> {
    return this.http.post<Driverpayment>(this.baseUrl, driverpayment, headerOption).pipe(
      tap(() => {
        this._refreshNeeded$.next();
      })
    );
  }

  updateDriverPayment(driverpayment: Driverpayment): Observable<Driverpayment> {
    return this.http
      .put<Driverpayment>(this.baseUrl + '/' + driverpayment.paymentid, driverpayment)
      .pipe(
        tap(() => {
          this._refreshNeeded$.next();
        })
      );
  }

  deleteDriverPayment(paymentid: number): Observable<Driverpayment> {
    return this.http.delete<Driverpayment>(this.baseUrl + '/' + paymentid);
  }

  getDriverPaymentById(paymentid: number): Observable<Driverpayment> {
    return this.http.get<Driverpayment>(this.baseUrl + '/' + paymentid, headerOption);
  }

}
