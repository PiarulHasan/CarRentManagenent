import { Component, OnInit } from '@angular/core';
import { Driverpayment } from './driver-payment';
import { DriverPaymentService } from '../driver-payment.service';

@Component({
  selector: 'app-driver-payment',
  templateUrl: './driver-payment.component.html',
  styleUrls: ['./driver-payment.component.css']
})
export class DriverPaymentComponent implements OnInit {
  
  driverPayment: Driverpayment[];
  constructor(public driverPaymentService : DriverPaymentService) {

    this.getAllPackage();
    this.driverPaymentService.refreshNeeded$.subscribe(() => {
      this.getAllPackage();
    });
    this.getAllPackage();

   }
   

  ngOnInit() {
  }

  createOrUpdate(currentDriverpayment: Driverpayment) {
    if (currentDriverpayment.paymentid != null) {
      this.updateDriverpayment(currentDriverpayment);
    } else {
      this.createDriverpayment(currentDriverpayment);
    }
  }

  updateDriverpayment(currentDriverpayment: Driverpayment) {
    this.driverPaymentService.updateDriverPayment(currentDriverpayment).subscribe();
  }

  createDriverpayment(currentDriverpayment: Driverpayment) {
    this.driverPaymentService.createDriverPayment(currentDriverpayment).subscribe();
    this.ngOnInit();
  }

  clear() {
    this.driverPaymentService.driverpayment = {
    paymentid : null,
    driverid : null,
    payamount : null,
    date : new Date,
    
    };
}

getAllPackage() {
  this.driverPaymentService.getAllDriverPayment().subscribe((data: Driverpayment[]) => {
    this.driverPayment = data;
  });
}

deletePack(tpackid: number) {
  this.driverPaymentService.deleteDriverPayment(tpackid).subscribe((data: Driverpayment) => {
    this.getAllPackage();
  });
}

editPack(pc: Driverpayment) {
  this.driverPaymentService.driverpayment = Object.assign({}, pc);
  
}

}

