import { DriverPaymentModule } from './driver-payment.module';

describe('DriverPaymentModule', () => {
  let driverPaymentModule: DriverPaymentModule;

  beforeEach(() => {
    driverPaymentModule = new DriverPaymentModule();
  });

  it('should create an instance', () => {
    expect(driverPaymentModule).toBeTruthy();
  });
});
