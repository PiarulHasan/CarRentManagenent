export class Driverpayment{
    paymentid : number;
    driverid : number;
    payamount : number;
    date : Date;
    
    }