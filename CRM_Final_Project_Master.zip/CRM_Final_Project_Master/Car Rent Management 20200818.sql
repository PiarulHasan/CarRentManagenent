-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.41-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema car_rent
--

CREATE DATABASE IF NOT EXISTS car_rent;
USE car_rent;

--
-- Definition of table `booking`
--

DROP TABLE IF EXISTS `booking`;
CREATE TABLE `booking` (
  `bookingid` int(10) unsigned NOT NULL auto_increment,
  `carid` varchar(45) NOT NULL,
  `carname` varchar(45) NOT NULL,
  `date` date NOT NULL,
  `days` int(10) unsigned NOT NULL,
  `price` double NOT NULL,
  `subtotal` double NOT NULL,
  `ststus` varchar(45) NOT NULL,
  `custid` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`bookingid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

/*!40000 ALTER TABLE `booking` DISABLE KEYS */;
INSERT INTO `booking` (`bookingid`,`carid`,`carname`,`date`,`days`,`price`,`subtotal`,`ststus`,`custid`) VALUES 
 (2,'3','ktm','2020-08-18',1,2000,2000,'done',5),
 (3,'2','benze','2020-08-18',2,5000,10000,'pending',5),
 (4,'1','honda','2020-08-18',2,2000,4000,'pending',5),
 (5,'1','honda','2020-08-18',3,2000,6000,'pending',7),
 (6,'2','benze','2020-08-18',2,5000,10000,'pending',7),
 (7,'3','ktm','2020-08-18',2,2000,4000,'pending',7),
 (8,'1','honda','2020-08-18',1,2000,2000,'pending',3),
 (9,'2','benze','2020-08-18',2,5000,10000,'pending',3),
 (10,'3','ktm','2020-08-18',1,2000,2000,'pending',3);
/*!40000 ALTER TABLE `booking` ENABLE KEYS */;


--
-- Definition of table `campanypayment`
--

DROP TABLE IF EXISTS `campanypayment`;
CREATE TABLE `campanypayment` (
  `paymentid` int(10) unsigned NOT NULL auto_increment,
  `companyid` int(10) unsigned NOT NULL,
  `payamount` double NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY  USING BTREE (`paymentid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `campanypayment`
--

/*!40000 ALTER TABLE `campanypayment` DISABLE KEYS */;
INSERT INTO `campanypayment` (`paymentid`,`companyid`,`payamount`,`date`) VALUES 
 (1,1,4000,'2020-02-10');
/*!40000 ALTER TABLE `campanypayment` ENABLE KEYS */;


--
-- Definition of table `carcompany`
--

DROP TABLE IF EXISTS `carcompany`;
CREATE TABLE `carcompany` (
  `companyid` int(10) unsigned NOT NULL auto_increment,
  `catid` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  `phone` varchar(45) NOT NULL,
  `price` double NOT NULL,
  `email` varchar(45) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY  (`companyid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `carcompany`
--

/*!40000 ALTER TABLE `carcompany` DISABLE KEYS */;
INSERT INTO `carcompany` (`companyid`,`catid`,`name`,`address`,`phone`,`price`,`email`,`date`) VALUES 
 (1,'1','joynal','Dhaka','12523324',100,'joynal@gmail.com','2020-02-15'),
 (2,'1','Hasan','Dhaka','12523324',100,'Hasan@gmail.com','2020-02-15'),
 (3,'1','Borhan','Dhaka','013523324',3500,'john@gmail.com','2020-01-15'),
 (5,'3','Jaman','Manikgong','01944992626',100,'jaman@gmail.com','2020-08-04');
/*!40000 ALTER TABLE `carcompany` ENABLE KEYS */;


--
-- Definition of table `cardetails`
--

DROP TABLE IF EXISTS `cardetails`;
CREATE TABLE `cardetails` (
  `carid` int(10) unsigned NOT NULL auto_increment,
  `catid` int(10) unsigned NOT NULL,
  `brand` varchar(45) NOT NULL,
  `rantprice` double NOT NULL,
  `image` varchar(45) NOT NULL,
  `colour` varchar(45) NOT NULL,
  `fuel` varchar(45) NOT NULL,
  `mileage` varchar(45) NOT NULL,
  `carcategory` varchar(45) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY  (`carid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cardetails`
--

/*!40000 ALTER TABLE `cardetails` DISABLE KEYS */;
INSERT INTO `cardetails` (`carid`,`catid`,`brand`,`rantprice`,`image`,`colour`,`fuel`,`mileage`,`carcategory`,`status`) VALUES 
 (1,1,'honda',2000,'abc.jpge','red','40','20','privatecar',1),
 (2,1,'benze',5000,'abc.jpge','silver','35','20','privatecar',1),
 (3,1,'ktm',2000,'xyz.jpge','orange','40','20','privatecar',1),
 (8,6,'Benze',3400,'Na','Green','55','43','Minibus',1),
 (9,2,'Audi',5400,'Na','silver','33','32','Privatecar',1),
 (10,1,'Audi',3450,'NA','Orange','40','45','Privatecar',1);
/*!40000 ALTER TABLE `cardetails` ENABLE KEYS */;


--
-- Definition of table `cardriver`
--

DROP TABLE IF EXISTS `cardriver`;
CREATE TABLE `cardriver` (
  `driverid` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  `phone` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `licenseno` varchar(45) NOT NULL,
  `expyear` varchar(45) NOT NULL,
  `location` varchar(45) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY  (`driverid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cardriver`
--

/*!40000 ALTER TABLE `cardriver` DISABLE KEYS */;
INSERT INTO `cardriver` (`driverid`,`name`,`address`,`phone`,`email`,`licenseno`,`expyear`,`location`,`status`) VALUES 
 (1,'kalam','mirpur','01675854585','kalam@gmail.com','3586954652','5','Mirpur-10',1),
 (2,'jamal','dhaka','01675867980','jamal@gmail.com','534089276','8','dhaka',1),
 (4,'Manik','Uttara','01677577234','manik@gmail.com','384627273453','7','dhaka',1),
 (5,'Jhon','Dhaka','01793000000','jhon12@gmail.com','35872973347','5','Mirpur',1);
/*!40000 ALTER TABLE `cardriver` ENABLE KEYS */;


--
-- Definition of table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `catid` int(10) unsigned NOT NULL auto_increment,
  `catname` varchar(45) NOT NULL,
  `description` varchar(45) NOT NULL,
  PRIMARY KEY  (`catid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` (`catid`,`catname`,`description`) VALUES 
 (1,'Car','Private Car'),
 (2,'Microbus','Hayice Car'),
 (3,'Car','Probox Car'),
 (4,'Minibus','Bus'),
 (5,'Car','car'),
 (6,'Microbus','bus'),
 (7,'Microbus','car'),
 (8,'Minibus','gfghf');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;


--
-- Definition of table `companypayment`
--

DROP TABLE IF EXISTS `companypayment`;
CREATE TABLE `companypayment` (
  `paymentid` int(10) unsigned NOT NULL auto_increment,
  `companyid` int(10) unsigned NOT NULL,
  `payamount` double NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY  (`paymentid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `companypayment`
--

/*!40000 ALTER TABLE `companypayment` DISABLE KEYS */;
INSERT INTO `companypayment` (`paymentid`,`companyid`,`payamount`,`date`) VALUES 
 (1,1,2000,'2020-02-15'),
 (2,2,4000,'2020-01-16'),
 (4,3,3000,'2020-08-06'),
 (5,4,4500,'2020-08-06');
/*!40000 ALTER TABLE `companypayment` ENABLE KEYS */;


--
-- Definition of table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `custid` int(10) unsigned NOT NULL auto_increment,
  `custname` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  `phone` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `location` varchar(45) NOT NULL,
  PRIMARY KEY  (`custid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` (`custid`,`custname`,`address`,`phone`,`email`,`location`) VALUES 
 (1,'jamal','Mirpur','01794116226','jamal@gmail.com','Dhaka'),
 (2,'jony','Cantonment','01393116116','jony@gmail.com','Dhaka'),
 (3,'Hasan','Cantonment','01393116116','jony@gmail.com','Dhaka'),
 (5,'Sayem','Munshiganj','456465','sayem@gmail.com','Dhaka'),
 (6,'piarul','mirpur','241524','adsfkh@ajdf','Dhaka'),
 (7,'Sajid','munshiganj','5454','sdfs@gasmk.com','dahak');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;


--
-- Definition of table `driverpayment`
--

DROP TABLE IF EXISTS `driverpayment`;
CREATE TABLE `driverpayment` (
  `paymentid` int(10) unsigned NOT NULL auto_increment,
  `driverid` int(10) unsigned NOT NULL,
  `payamount` double NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY  (`paymentid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `driverpayment`
--

/*!40000 ALTER TABLE `driverpayment` DISABLE KEYS */;
INSERT INTO `driverpayment` (`paymentid`,`driverid`,`payamount`,`date`) VALUES 
 (1,1,5000,'2020-07-10'),
 (2,2,2200,'2020-08-07'),
 (3,3,3400,'2020-08-10'),
 (4,4,3000,'2020-08-10');
/*!40000 ALTER TABLE `driverpayment` ENABLE KEYS */;


--
-- Definition of table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `emailid` varchar(45) NOT NULL,
  `uname` varchar(45) NOT NULL,
  `phone` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  PRIMARY KEY  USING BTREE (`emailid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`emailid`,`uname`,`phone`,`address`) VALUES 
 ('hasan@gmail.com','hasan','01793266566','dhaka');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;


--
-- Definition of table `userrole`
--

DROP TABLE IF EXISTS `userrole`;
CREATE TABLE `userrole` (
  `emailid` varchar(45) NOT NULL,
  `pass` varchar(45) NOT NULL,
  `role` varchar(45) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY  USING BTREE (`emailid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userrole`
--

/*!40000 ALTER TABLE `userrole` DISABLE KEYS */;
INSERT INTO `userrole` (`emailid`,`pass`,`role`,`status`) VALUES 
 ('hasan@gmail.com','123','admin',1);
/*!40000 ALTER TABLE `userrole` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
