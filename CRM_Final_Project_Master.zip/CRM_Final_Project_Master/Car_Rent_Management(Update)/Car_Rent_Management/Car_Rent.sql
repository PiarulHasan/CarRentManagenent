-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.41-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema car_rent
--

CREATE DATABASE IF NOT EXISTS car_rent;
USE car_rent;

--
-- Definition of table `carcompany`
--

DROP TABLE IF EXISTS `carcompany`;
CREATE TABLE `carcompany` (
  `companyid` int(10) unsigned NOT NULL,
  `catid` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  `phone` varchar(45) NOT NULL,
  `price` double NOT NULL,
  `email` varchar(45) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY  (`companyid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `carcompany`
--

/*!40000 ALTER TABLE `carcompany` DISABLE KEYS */;
INSERT INTO `carcompany` (`companyid`,`catid`,`name`,`address`,`phone`,`price`,`email`,`date`) VALUES 
 (1,'1','john','Dhaka','12523324',100,'john@gmail.com','2020-02-15'),
 (2,'1','Hasan','Dhaka','12523324',100,'Hasan@gmail.com','2020-02-15'),
 (3,'1','bohn','Dhaka','013523324',100,'john@gmail.com','2020-01-15');
/*!40000 ALTER TABLE `carcompany` ENABLE KEYS */;


--
-- Definition of table `cardetails`
--

DROP TABLE IF EXISTS `cardetails`;
CREATE TABLE `cardetails` (
  `carid` int(10) unsigned NOT NULL,
  `catid` int(10) unsigned NOT NULL,
  `brand` varchar(45) NOT NULL,
  `rantprice` double NOT NULL,
  `image` varchar(45) NOT NULL,
  `colour` varchar(45) NOT NULL,
  `fuel` varchar(45) NOT NULL,
  `mileage` varchar(45) NOT NULL,
  `carcategory` varchar(45) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY  (`carid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cardetails`
--

/*!40000 ALTER TABLE `cardetails` DISABLE KEYS */;
INSERT INTO `cardetails` (`carid`,`catid`,`brand`,`rantprice`,`image`,`colour`,`fuel`,`mileage`,`carcategory`,`status`) VALUES 
 (1,1,'honda',2000,'abc.jpge','red','40','20','privatecar',1),
 (2,1,'benze',5000,'abc.jpge','silver','35','20','privatecar',1),
 (3,1,'ktm',2000,'xyz.jpge','orange','40','20','privatecar',1);
/*!40000 ALTER TABLE `cardetails` ENABLE KEYS */;


--
-- Definition of table `cardriver`
--

DROP TABLE IF EXISTS `cardriver`;
CREATE TABLE `cardriver` (
  `driverid` int(10) unsigned NOT NULL,
  `name` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  `phone` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `licenseno` varchar(45) NOT NULL,
  `expyear` varchar(45) NOT NULL,
  `location` varchar(45) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY  (`driverid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cardriver`
--

/*!40000 ALTER TABLE `cardriver` DISABLE KEYS */;
INSERT INTO `cardriver` (`driverid`,`name`,`address`,`phone`,`email`,`licenseno`,`expyear`,`location`,`status`) VALUES 
 (1,'kalam','mirpur','01675854585','kalam@gmail.com','3586954652','5','mirpur',1),
 (2,'jamal','mirpur','01675854585','jamal@gmail.com','3586954652','10','mirpur',1);
/*!40000 ALTER TABLE `cardriver` ENABLE KEYS */;


--
-- Definition of table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `catid` int(10) unsigned NOT NULL,
  `catname` varchar(45) NOT NULL,
  `description` varchar(45) NOT NULL,
  PRIMARY KEY  (`catid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` (`catid`,`catname`,`description`) VALUES 
 (1,'Car','Private Car'),
 (2,'Microbus','Hayice Car'),
 (3,'Car','Probox Car');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;


--
-- Definition of table `companypayment`
--

DROP TABLE IF EXISTS `companypayment`;
CREATE TABLE `companypayment` (
  `paymentid` int(10) unsigned NOT NULL,
  `companyid` int(10) unsigned NOT NULL,
  `payamount` double NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY  (`paymentid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `companypayment`
--

/*!40000 ALTER TABLE `companypayment` DISABLE KEYS */;
INSERT INTO `companypayment` (`paymentid`,`companyid`,`payamount`,`date`) VALUES 
 (1,1,2000,'2020-02-15'),
 (2,2,4000,'2020-01-16'),
 (3,1,4000,'2020-03-10');
/*!40000 ALTER TABLE `companypayment` ENABLE KEYS */;


--
-- Definition of table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `customerid` int(10) unsigned NOT NULL,
  `carid` int(10) unsigned NOT NULL,
  `name` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  `phone` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `location` varchar(45) NOT NULL,
  `bookingdate` datetime NOT NULL,
  `relesedate` datetime NOT NULL,
  `rentprice` double NOT NULL,
  `driver` varchar(45) NOT NULL,
  `total` varchar(45) NOT NULL,
  PRIMARY KEY  (`customerid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` (`customerid`,`carid`,`name`,`address`,`phone`,`email`,`location`,`bookingdate`,`relesedate`,`rentprice`,`driver`,`total`) VALUES 
 (1,1,'jaman','dhaka','01726534652','jaman@gmail.com','manikdi','2020-01-10 00:00:00','2020-01-11 00:00:00',2000,'2','4000');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;


--
-- Definition of table `driverpayment`
--

DROP TABLE IF EXISTS `driverpayment`;
CREATE TABLE `driverpayment` (
  `paymentid` int(10) unsigned NOT NULL,
  `driverid` int(10) unsigned NOT NULL,
  `payamount` double NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY  (`paymentid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `driverpayment`
--

/*!40000 ALTER TABLE `driverpayment` DISABLE KEYS */;
INSERT INTO `driverpayment` (`paymentid`,`driverid`,`payamount`,`date`) VALUES 
 (1,1,5000,'2020-02-10'),
 (2,2,7000,'2020-03-10'),
 (4,2,7000,'2020-03-10');
/*!40000 ALTER TABLE `driverpayment` ENABLE KEYS */;


--
-- Definition of table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `emailid` varchar(45) NOT NULL,
  `uname` varchar(45) NOT NULL,
  `phone` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  PRIMARY KEY  USING BTREE (`emailid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`emailid`,`uname`,`phone`,`address`) VALUES 
 ('hasan@gmail.com','hasan','01793266566','dhaka');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;


--
-- Definition of table `userrole`
--

DROP TABLE IF EXISTS `userrole`;
CREATE TABLE `userrole` (
  `emailid` varchar(45) NOT NULL,
  `pass` varchar(45) NOT NULL,
  `role` varchar(45) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY  USING BTREE (`emailid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userrole`
--

/*!40000 ALTER TABLE `userrole` DISABLE KEYS */;
INSERT INTO `userrole` (`emailid`,`pass`,`role`,`status`) VALUES 
 ('hasan@gmail.com','123','admin',1);
/*!40000 ALTER TABLE `userrole` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
