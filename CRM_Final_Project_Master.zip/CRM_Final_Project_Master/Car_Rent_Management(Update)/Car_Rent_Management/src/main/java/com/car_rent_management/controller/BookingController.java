/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.controller;

import com.car_rent_management.model.Booking;
import com.car_rent_management.service.BookingService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author kawsar
 */
@RestController
@RequestMapping(value = "/api/v1")
public class BookingController {
    @Autowired
    private BookingService bookingService;
    
    @GetMapping("/booking")
    public List<Booking> getAllBooking() {
        return bookingService.viewAllBooking();
    }
    @GetMapping("/booking/bookinglist")
    public List<Booking> getAllBookingCarname() {
        return bookingService.viewAllBookingCarname();
    }
    
    @GetMapping("/booking/{bookingid}")
    public ResponseEntity<Booking> getOneBooking(@PathVariable("bookingid") int bookingid) {
        Booking booking = bookingService.viewOneBooking(bookingid);
        if (booking == null) {
            return new ResponseEntity<Booking>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Booking>(booking, HttpStatus.OK);
    }
    
    @GetMapping("/booking/booking/{carname}")
    public ResponseEntity<Booking> getBookingByCarname(@PathVariable("carname") String carname){
        Booking booking = bookingService.viewBookingByCarname(carname);
        if (booking == null){
            return new ResponseEntity<Booking>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Booking>(booking, HttpStatus.OK);
    }
    
    @GetMapping("/booking/bookingid/{carname}")
    public ResponseEntity<Integer> getCarBookingIdByCarname(@PathVariable("carname") String carname){
        Booking booking = bookingService.viewBookingByCarname(carname);
        if (booking == null){
            return new ResponseEntity<Integer>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Integer>(booking.getBookingid(), HttpStatus.OK);
    }
    
    @GetMapping("/booking/carname/{bookingid}")
    public ResponseEntity<String> getOneBookingCarnameById(@PathVariable("bookingid") int bookingid){
        Booking booking = bookingService.viewOneBooking(bookingid);
        if (booking == null){
            return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<String>(booking.getCarname(), HttpStatus.OK);
    }
    
    @PostMapping("/booking")
    public Booking createBooking(@RequestBody Booking Booking){
        return bookingService.insertBooking(Booking);
    }
    
    @PutMapping("/booking/{bookingid}")
    public ResponseEntity<Booking> updateBooking(@PathVariable("bookingid") int bookingid, @RequestBody Booking Booking){
        
        Booking currentBooking = bookingService.viewOneBooking(bookingid);
        
        if (currentBooking == null){
            return new ResponseEntity<Booking>(HttpStatus.NOT_FOUND);
        }
        
        currentBooking.setBookingid(Booking.getBookingid());
        currentBooking.setCarid(Booking.getCarid());
        currentBooking.setCarname(Booking.getCarname());
        currentBooking.setDate(Booking.getDate());
        currentBooking.setDays(Booking.getDays());
        currentBooking.setPrice(Booking.getPrice());
        currentBooking.setSubtotal(Booking.getSubtotal());
        currentBooking.setStstus(Booking.getStstus());
        currentBooking.setCustid(Booking.getCustid());
        
        
        bookingService.updateBooking(Booking);
        
        return new ResponseEntity<Booking>(currentBooking, HttpStatus.OK);
    }
    
    @DeleteMapping("/booking/{bookingid}")
    public ResponseEntity<Booking> deleteBooking(@PathVariable("bookingid") int bookingid){
        Booking booking = bookingService.viewOneBooking(bookingid);
        if (booking == null){
            return new ResponseEntity<Booking>(HttpStatus.NOT_FOUND);
        }
        bookingService.deleteBooking(bookingid);
        return new ResponseEntity<Booking>(HttpStatus.NO_CONTENT);
    }
}
