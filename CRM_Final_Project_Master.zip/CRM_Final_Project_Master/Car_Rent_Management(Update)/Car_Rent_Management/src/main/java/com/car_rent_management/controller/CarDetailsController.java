/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.controller;

import com.car_rent_management.model.CarDetails;
import com.car_rent_management.service.CarDetailsService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author kawsar
 */
//@CrossOrigin(allowedHeaders = "http://localhost:4200")
@RestController
@RequestMapping(value = "/api/v1")
public class CarDetailsController {
    @Autowired
    private CarDetailsService carDetailsService;
    
    @GetMapping("/cardetails")
    public List<CarDetails> getAllCarDetails() {
        return carDetailsService.viewAllCarDetails();
    }
    
    @GetMapping("/cardetails/cardetailslist")
    public List<CarDetails> getAllCarDetailsBrand() {
        return carDetailsService.viewAllCarDetailsBrand();
    }
    
    @GetMapping("/cardetails/{carid}")
    public ResponseEntity<CarDetails> getOneCarDetails(@PathVariable("carid") int carid) {
        CarDetails carDetails = carDetailsService.viewOneCarDetails(carid);
        if (carDetails == null) {
            return new ResponseEntity<CarDetails>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<CarDetails>(carDetails, HttpStatus.OK);
    }
    
    @GetMapping("/cardetails/cardetails/{brand}")
    public ResponseEntity<CarDetails> getCarDetailsByBrand(@PathVariable("brand") String brand){
        CarDetails carDetails = carDetailsService.viewCardetailsByBrand(brand);
        if (carDetails == null){
            return new ResponseEntity<CarDetails>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<CarDetails>(carDetails, HttpStatus.OK);
    }
    
    @GetMapping("/cardetails/carid/{brand}")
    public ResponseEntity<Integer> getCarDetailsIdByBrand(@PathVariable("brand") String brand){
        CarDetails carDetails = carDetailsService.viewCardetailsByBrand(brand);
        if (carDetails == null){
            return new ResponseEntity<Integer>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Integer>(carDetails.getCarid(), HttpStatus.OK);
    }
    
    @GetMapping("/cardetails/brand/{carid}")
    public ResponseEntity<String> getOneCarDetailsBrandById(@PathVariable("carid") int carid){
        CarDetails carDetails = carDetailsService.viewOneCarDetails(carid);
        if (carDetails == null){
            return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<String>(carDetails.getBrand(), HttpStatus.OK);
    }
    
    @PostMapping("/cardetails")
    public CarDetails createCarDetails(@RequestBody CarDetails CarDetails){
        return carDetailsService.insertCardetails(CarDetails);
    }
    
    @PutMapping("/cardetails/{carid}")
    public ResponseEntity<CarDetails> updateCarDetails(@PathVariable("carid") int carid, @RequestBody CarDetails CarDetails){
        
        CarDetails currentcarDetails = carDetailsService.viewOneCarDetails(carid);
        
        if (currentcarDetails == null){
            return new ResponseEntity<CarDetails>(HttpStatus.NOT_FOUND);
        }
        
        currentcarDetails.setCarid(CarDetails.getCarid());
        currentcarDetails.setCatid(CarDetails.getCatid());
        currentcarDetails.setBrand(CarDetails.getBrand());
        currentcarDetails.setRantprice(CarDetails.getRantprice());
        currentcarDetails.setImage(CarDetails.getImage());
        currentcarDetails.setColour(CarDetails.getColour());
        currentcarDetails.setFuel(CarDetails.getFuel());
        currentcarDetails.setMileage(CarDetails.getMileage());
        currentcarDetails.setCarcategory(CarDetails.getCarcategory());
        currentcarDetails.setStatus(true);        
        
        
        carDetailsService.updateCardetails(CarDetails);
        
        return new ResponseEntity<CarDetails>(currentcarDetails, HttpStatus.OK);
    }
    
    @DeleteMapping("/cardetails/{carid}")
    public ResponseEntity<CarDetails> deleteCarDetails(@PathVariable("carid") int carid){
        CarDetails carDetails = carDetailsService.viewOneCarDetails(carid);
        if (carDetails == null){
            return new ResponseEntity<CarDetails>(HttpStatus.NOT_FOUND);
        }
        carDetailsService.deleteCardetails(carid);
        return new ResponseEntity<CarDetails>(HttpStatus.NO_CONTENT);
    }
}
