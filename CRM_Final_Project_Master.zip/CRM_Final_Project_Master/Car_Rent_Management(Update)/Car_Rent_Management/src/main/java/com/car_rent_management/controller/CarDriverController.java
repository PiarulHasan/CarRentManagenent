/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.controller;

import com.car_rent_management.model.CarDriver;
import com.car_rent_management.service.CarDriverService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author HASAN
 */
@RestController
@RequestMapping(value = "/api/v1")
public class CarDriverController {
    @Autowired
    public CarDriverService carDriverService;
    
    @GetMapping("/cardriver")
    public List<CarDriver> getAllCarDriver() {
        return carDriverService.viewAllCarDriver();
    }
    
    @GetMapping("/cardriver/cardriverlist")
    public List<CarDriver> getAllCarDriverName() {
        return carDriverService.viewAllCarDriverName();
    }
    
    @GetMapping("/cardriver/{driverid}")
    public ResponseEntity<CarDriver> getOneCarDriver(@PathVariable("driverid") int driverid) {
        CarDriver carDriver = carDriverService.viewOneCarDriver(driverid);
        if (carDriver == null) {
            return new ResponseEntity<CarDriver>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<CarDriver>(carDriver, HttpStatus.OK);
    }
    
    @GetMapping("/cardriver/cardriver/{name}")
    public ResponseEntity<CarDriver> getCarDriverByName(@PathVariable("name") String name){
        CarDriver carDriver = carDriverService.viewCarDriverByName(name);
        if (carDriver == null){
            return new ResponseEntity<CarDriver>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<CarDriver>(carDriver, HttpStatus.OK);
    }
    
    @GetMapping("/cardriver/id/{name}")
    public ResponseEntity<Integer> getCarDriverIdByName(@PathVariable("name") String name){
        CarDriver carDriver = carDriverService.viewCarDriverByName(name);
        if (carDriver == null){
            return new ResponseEntity<Integer>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Integer>(carDriver.getDriverid(), HttpStatus.OK);
    }
    
    @GetMapping("/cardriver/name/{driverid}")
    public ResponseEntity<String> getOneCarDriverNameById(@PathVariable("driverid") int driverid){
        CarDriver carDriver = carDriverService.viewOneCarDriver(driverid);
        if (carDriver == null){
            return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<String>(carDriver.getName(), HttpStatus.OK);
    }
    
    @PostMapping("/cardriver")
    public CarDriver createCarDriver(@RequestBody CarDriver carDriver){
        return carDriverService.insertCarDriver(carDriver);
    }
    
    @PutMapping("/cardriver/{driverid}")
    public ResponseEntity<CarDriver> updateCarDriver(@PathVariable("driverid") int driverid, @RequestBody CarDriver carDriver){
        
        CarDriver currentCarDriver = carDriverService.viewOneCarDriver(driverid);
        
        if (currentCarDriver == null){
            return new ResponseEntity<CarDriver>(HttpStatus.NOT_FOUND);
        }
        
        currentCarDriver.setDriverid(carDriver.getDriverid());
        currentCarDriver.setName(carDriver.getName());
        currentCarDriver.setAddress(carDriver.getAddress());
        currentCarDriver.setPhone(carDriver.getPhone());
        currentCarDriver.setEmail(carDriver.getEmail());
        currentCarDriver.setLicenseno(carDriver.getLicenseno());
        currentCarDriver.setExpyear(carDriver.getExpyear());
        currentCarDriver.setLocation(carDriver.getLocation());
        currentCarDriver.setStatus(true);
        
        carDriverService.updateCarDriver(carDriver);
        
        return new ResponseEntity<CarDriver>(currentCarDriver, HttpStatus.OK);
    }
    
    @DeleteMapping("/cardriver/{driverid}")
    public ResponseEntity<CarDriver> deleteCarDriver(@PathVariable("driverid") int driverid){
        CarDriver cardriver = carDriverService.viewOneCarDriver(driverid);
        if (cardriver == null){
            return new ResponseEntity<CarDriver>(HttpStatus.NOT_FOUND);
        }
        carDriverService.deleteCarDriver(driverid);
        return new ResponseEntity<CarDriver>(HttpStatus.NO_CONTENT);
    }
    
}
