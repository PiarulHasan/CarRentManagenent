/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.controller;

import com.car_rent_management.model.Carcompany;
import com.car_rent_management.service.CarcompanyService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author HASAN
 */
@RestController
@RequestMapping(value = "/api/v1")
public class CarcompanyController {

    @Autowired
    private CarcompanyService carcompanyService;
    
    @GetMapping("/carcompany")
    public List<Carcompany> getAllCarcompany() {
        return carcompanyService.viewAllCarcompany();
    }
    
    @GetMapping("/carcompany/carcompanylist")
    public List<Carcompany> getAllCarcompanyName() {
        return carcompanyService.viewAllCarcompanyName();
    }
    
    @GetMapping("/carcompany/{companyid}")
    public ResponseEntity<Carcompany> getOneCarcompany(@PathVariable("companyid") int companyid) {
        Carcompany carcompany = carcompanyService.viewOneCarcompany(companyid);
        if (carcompany == null) {
            return new ResponseEntity<Carcompany>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Carcompany>(carcompany, HttpStatus.OK);
    }
    
    @GetMapping("/carcompany/carcompany/{name}")
    public ResponseEntity<Carcompany> getCarcompanyByName(@PathVariable("name") String name){
        Carcompany carcompany = carcompanyService.viewCarcompanyByName(name);
        if (carcompany == null){
            return new ResponseEntity<Carcompany>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Carcompany>(carcompany, HttpStatus.OK);
    }
    
    @GetMapping("/carcompany/id/{name}")
    public ResponseEntity<Integer> getCategoryIdByName(@PathVariable("name") String name){
        Carcompany carcompany = carcompanyService.viewCarcompanyByName(name);
        if (carcompany == null){
            return new ResponseEntity<Integer>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Integer>(carcompany.getCompanyid(), HttpStatus.OK);
    }
    
    @GetMapping("/carcompany/name/{companyid}")
    public ResponseEntity<String> getOneCategoryNameById(@PathVariable("companyid") int companyid){
        Carcompany carcompany = carcompanyService.viewOneCarcompany(companyid);
        if (carcompany == null){
            return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<String>(carcompany.getName(), HttpStatus.OK);
    }
    
    @PostMapping("/carcompany")
    public Carcompany createCarcompany(@RequestBody Carcompany carcompany){
        return carcompanyService.insertCarcompany(carcompany);
    }
    
    @PutMapping("/carcompany/{companyid}")
    public ResponseEntity<Carcompany> updateCarcompany(@PathVariable("companyid") int companyid, @RequestBody Carcompany carcompany){
        
        Carcompany currentcarCarcompany = carcompanyService.viewOneCarcompany(companyid);
        
        if (currentcarCarcompany == null){
            return new ResponseEntity<Carcompany>(HttpStatus.NOT_FOUND);
        }
        
        currentcarCarcompany.setCompanyid(carcompany.getCompanyid());
        currentcarCarcompany.setCatid(carcompany.getCatid());
        currentcarCarcompany.setName(carcompany.getName());
        currentcarCarcompany.setAddress(carcompany.getAddress());
        currentcarCarcompany.setPhone(carcompany.getPhone());
        currentcarCarcompany.setPrice(carcompany.getPrice());
        currentcarCarcompany.setEmail(carcompany.getEmail());
        currentcarCarcompany.setDate(carcompany.getDate());
        
        
        
        carcompanyService.updateCarcompany(carcompany);
        
        return new ResponseEntity<Carcompany>(currentcarCarcompany, HttpStatus.OK);
    }
    
    @DeleteMapping("/carcompany/{companyid}")
    public ResponseEntity<Carcompany> deleteCategory(@PathVariable("companyid") int companyid){
        Carcompany carcompany = carcompanyService.viewOneCarcompany(companyid);
        if (carcompany == null){
            return new ResponseEntity<Carcompany>(HttpStatus.NOT_FOUND);
        }
        carcompanyService.deleteCarcompany(companyid);
        return new ResponseEntity<Carcompany>(HttpStatus.NO_CONTENT);
    }
    
    
    
    
}
