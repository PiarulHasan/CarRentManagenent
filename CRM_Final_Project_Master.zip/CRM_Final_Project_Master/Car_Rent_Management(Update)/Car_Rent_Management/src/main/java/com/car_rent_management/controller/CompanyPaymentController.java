/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.controller;

import com.car_rent_management.model.CompanyPayment;
import com.car_rent_management.service.CompanyPaymentService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author HASAN
 */
@RestController
@RequestMapping(value = "/api/v1")
public class CompanyPaymentController {
    @Autowired
    public CompanyPaymentService companyPaymentService;
    
    @GetMapping("/cpayment")
    public List<CompanyPayment> getAllCompanyPayment() {
        return companyPaymentService.viewAllCompanyPayment();
    }
    
    @GetMapping("/cpayment/{paymentid}")
    public ResponseEntity<CompanyPayment> getOneCompanyPayment(@PathVariable("paymentid") int paymentid) {
        CompanyPayment companyPayment = companyPaymentService.viewOneCompanyPayment(paymentid);
        if (companyPayment == null) {
            return new ResponseEntity<CompanyPayment>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<CompanyPayment>(companyPayment, HttpStatus.OK);
    }
    
    @PostMapping("/cpayment")
    public CompanyPayment createCompanyPayment(@RequestBody CompanyPayment companyPayment){
        return companyPaymentService.insertCompanyPayment(companyPayment);
    }
    
    @PutMapping("/cpayment/{paymentid}")
    public ResponseEntity<CompanyPayment> updateCompanyPayment(@PathVariable("paymentid") int paymentid, @RequestBody CompanyPayment companyPayment){
        
        CompanyPayment currentCompanyPayment = companyPaymentService.viewOneCompanyPayment(paymentid);
        
        if (currentCompanyPayment == null){
            return new ResponseEntity<CompanyPayment>(HttpStatus.NOT_FOUND);
        }
        
        currentCompanyPayment.setPaymentid(companyPayment.getPaymentid());
        currentCompanyPayment.setCompanyid(companyPayment.getCompanyid());
        currentCompanyPayment.setPayamount(companyPayment.getPayamount());
        currentCompanyPayment.setDate(companyPayment.getDate());
        
        
        companyPaymentService.updateCompanyPayment(companyPayment);
        
        return new ResponseEntity<CompanyPayment>(currentCompanyPayment, HttpStatus.OK);
    }
    
    @DeleteMapping("/cpayment/{paymentid}")
    public ResponseEntity<CompanyPayment> deleteCompanyPayment(@PathVariable("paymentid") int paymentid){
        CompanyPayment companyPayment = companyPaymentService.viewOneCompanyPayment(paymentid);
        if (companyPayment == null){
            return new ResponseEntity<CompanyPayment>(HttpStatus.NOT_FOUND);
        }
        companyPaymentService.deleteCompanyPayment(paymentid);
        return new ResponseEntity<CompanyPayment>(HttpStatus.NO_CONTENT);
    }
}
