/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.controller;

import com.car_rent_management.model.Customer;
import com.car_rent_management.service.CustomerService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author kawsar
 */
@RestController
@RequestMapping(value = "/api/v1")
public class CustomerController {
    @Autowired
    private CustomerService customerService;
    
    @GetMapping("/customer")
    public List<Customer> getAllCustomer() {
        return customerService.viewAllCustomer();
    }
    @GetMapping("/customer/customerlist")
    public List<Customer> getAllCustomerCustname() {
        return customerService.viewAllCustomerCustname();
    }
    
    @GetMapping("/customer/{custid}")
    public ResponseEntity<Customer> getOneCustomer(@PathVariable("custid") int custid) {
        Customer customer = customerService.viewOneCustomer(custid);
        if (customer == null) {
            return new ResponseEntity<Customer>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Customer>(customer, HttpStatus.OK);
    }
    
    @GetMapping("/customer/customer/{custname}")
    public ResponseEntity<Customer> getCustomerByCustname(@PathVariable("custname") String custname){
        Customer customer = customerService.viewCustomerByCustname(custname);
        if (customer == null){
            return new ResponseEntity<Customer>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Customer>(customer, HttpStatus.OK);
    }
    
    @GetMapping("/customer/custid/{custname}")
    public ResponseEntity<Integer> getCustomerIdByCustname(@PathVariable("custname") String custname){
        Customer customer = customerService.viewCustomerByCustname(custname);
        if (customer == null){
            return new ResponseEntity<Integer>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Integer>(customer.getCustid(), HttpStatus.OK);
    }
    
    @GetMapping("/customer/custname/{custid}")
    public ResponseEntity<String> getOneCustomerCustnameById(@PathVariable("custid") int custid){
        Customer customer = customerService.viewOneCustomer(custid);
        if (customer == null){
            return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<String>(customer.getCustname(), HttpStatus.OK);
    }
    
    @PostMapping("/customer")
    public Customer createCustomer(@RequestBody Customer Customer){
        return customerService.insertCustomer(Customer);
    }
    
    @PutMapping("/customer/{custid}")
    public ResponseEntity<Customer> updateCustomer(@PathVariable("custid") int custid, @RequestBody Customer Customer){
        
        Customer currCustomer = customerService.viewOneCustomer(custid);
        
        if (currCustomer == null){
            return new ResponseEntity<Customer>(HttpStatus.NOT_FOUND);
        }
        
        currCustomer.setCustid(Customer.getCustid());
        currCustomer.setCustname(Customer.getCustname());
        currCustomer.setAddress(Customer.getAddress());
        currCustomer.setPhone(Customer.getPhone());
        currCustomer.setEmail(Customer.getEmail());
        currCustomer.setLocation(Customer.getLocation());
        
               
        customerService.updateCustomer(Customer);
        
        return new ResponseEntity<Customer>(currCustomer, HttpStatus.OK);
    }
    
    @DeleteMapping("/customer/{custid}")
    public ResponseEntity<Customer> deleteCustomer(@PathVariable("custid") int custid){
        Customer customer = customerService.viewOneCustomer(custid);
        if (customer == null){
            return new ResponseEntity<Customer>(HttpStatus.NOT_FOUND);
        }
        customerService.deleteCustomer(custid);
        return new ResponseEntity<Customer>(HttpStatus.NO_CONTENT);
    }
    
}
