/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.controller;

import com.car_rent_management.model.DriverPayment;
import com.car_rent_management.service.DriverPaymentService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author HASAN
 */
@RestController
@RequestMapping(value = "/api/v1")
public class DriverPaymentController {
    @Autowired
    public DriverPaymentService driverPaymentService;
    
    @GetMapping("/dpayment")
    public List<DriverPayment> getAllDriverPayment() {
        return driverPaymentService.viewAllDriverPayment();
    }
    
    @GetMapping("/dpayment/{paymentid}")
    public ResponseEntity<DriverPayment> getOneDriverPayment(@PathVariable("paymentid") int paymentid) {
        DriverPayment driverPayment = driverPaymentService.viewOneDriverPayment(paymentid);
        if (driverPayment == null) {
            return new ResponseEntity<DriverPayment>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<DriverPayment>(driverPayment, HttpStatus.OK);
    }
    
    @PostMapping("/dpayment")
    public DriverPayment createDriverPayment(@RequestBody DriverPayment driverPayment){
        return driverPaymentService.insertDriverPayment(driverPayment);
    }
    
    @PutMapping("/dpayment/{paymentid}")
    public ResponseEntity<DriverPayment> updateDriverPayment(@PathVariable("paymentid") int paymentid, @RequestBody DriverPayment driverPayment){
        
        DriverPayment currentDriverPayment = driverPaymentService.viewOneDriverPayment(paymentid);
        
        if (currentDriverPayment == null){
            return new ResponseEntity<DriverPayment>(HttpStatus.NOT_FOUND);
        }
        
        currentDriverPayment.setPaymentid(driverPayment.getPaymentid());
        currentDriverPayment.setDriverid(driverPayment.getDriverid());
        currentDriverPayment.setPayamount(driverPayment.getPayamount());
        currentDriverPayment.setDate(driverPayment.getDate());
        
        
        driverPaymentService.updateDriverPayment(driverPayment);
        
        return new ResponseEntity<DriverPayment>(currentDriverPayment, HttpStatus.OK);
    }
    
    @DeleteMapping("/dpayment/{paymentid}")
    public ResponseEntity<DriverPayment> deleteDriverPayment(@PathVariable("paymentid") int paymentid){
        DriverPayment driverPayment = driverPaymentService.viewOneDriverPayment(paymentid);
        if (driverPayment == null){
            return new ResponseEntity<DriverPayment>(HttpStatus.NOT_FOUND);
        }
        driverPaymentService.deleteDriverPayment(paymentid);
        return new ResponseEntity<DriverPayment>(HttpStatus.NO_CONTENT);
    }
}
