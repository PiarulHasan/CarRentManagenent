/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.controller;

import com.car_rent_management.model.Category;
import com.car_rent_management.model.Report;
import com.car_rent_management.repository.JasperReportDAO;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


/**
 *
 * @author kawsar
 */
@Controller
public class ReportController {
//    @RequestMapping(value = "/reportView", method = RequestMethod.GET)
//    public String loadSurveyPg(
//            @ModelAttribute("reportInputForm") Report reportInputForm, Model model) {
//        model.addAttribute("reportInputForm", reportInputForm);
//        return "report";
//    }
//    
//    @RequestMapping(value = "/reportView", method = RequestMethod.POST)
//    public String generateReport(@ModelAttribute("reportInputForm") Report reportInputForm,HttpServletRequest request,HttpServletResponse response) throws JRException, IOException, SQLException, NamingException {
//        String reportFileName = "Category";
//        JasperReportDAO jrdao = new JasperReportDAO();
//        Connection conn = null;
//        try {
//            conn = jrdao.getConnection();
//            String category = reportInputForm.getCategory();
//            HashMap<String, Object> hmParams = new HashMap<String, Object>();
//            hmParams.put("category", category);
//            JasperReport jasperReport = jrdao.getCompiledFile(reportFileName,request);
//
//            jrdao.generateReportPDF(response, hmParams, jasperReport, conn); 
//
//        } catch (SQLException sqlExp) {
//            System.out.println("Exception::" + sqlExp.toString());
//        } finally {
//            if (conn != null) {
//                try {
//                    conn.close();
//                    conn = null;
//                } catch (SQLException e) {
//                    // TODO Auto-generated catch block
//                    e.printStackTrace();
//                }
//
//            }
//
//        }
//
//        return null;
//    }
    
    
    
    
    
     @GetMapping("/reportView/{Carname}")
    public void generateReport(@PathVariable("Carname") String Carname, HttpServletRequest request, HttpServletResponse response) throws Exception, IOException, SQLException, NamingException {

        System.out.println("jasper report");

        String reportFileName = "Demo";
        
        JasperReportDAO jrdao = new JasperReportDAO();
        Connection conn = null;
        try {
            conn = jrdao.getConnection();
            
            HashMap<String, Object> hmParams = new HashMap<String, Object>();
            hmParams.put("Carname", Carname);
            
            
            JasperPrint jasperReport = jrdao.getCompiledFile(reportFileName, hmParams, request);
            
            response.setContentType("application/pdf");
            
            OutputStream out = response.getOutputStream();
            
            JasperExportManager.exportReportToPdfStream(jasperReport, out);

        } catch (SQLException sqlExp) {
            System.out.println("Exception::" + sqlExp.toString());
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                    conn = null;
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

            }

        }
    }
    
    
    
}
