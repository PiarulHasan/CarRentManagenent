/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.model;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author kawsar
 */
@Entity
public class Booking  implements java.io.Serializable {

     private Integer bookingid;
     private String carid;
     private String carname;
     private Date date;
     private Integer days;
     private double price;
     private double subtotal;
     private String ststus;
     private Integer custid;

    public Booking() {
    }

    public Booking(String carid, String carname, Date date, int days, double price, double subtotal, String status, int custid) {
       this.carid = carid;
       this.carname = carname;
       this.date = date;
       this.days = days;
       this.price = price;
       this.subtotal = subtotal;
       this.ststus = status;
       this.custid = custid;
    }
   
    @Column(name="bookingid", unique=true, nullable=false)
     @Id
    @GeneratedValue(strategy=IDENTITY)
    public Integer getBookingid() {
        return this.bookingid;
    }
    
    public void setBookingid(Integer bookingid) {
        this.bookingid = bookingid;
    }
    
    @Column(name="carid",nullable=false, length=45)
    public String getCarid() {
        return this.carid;
    }
    
    public void setCarid(String carid) {
        this.carid = carid;
    }
    @Column(name="carname",nullable=false, length=45)
    public String getCarname() {
        return this.carname;
    }
    
    public void setCarname(String carname) {
        this.carname = carname;
    }
    @Temporal(TemporalType.DATE)
    @Column(name="date")
    public Date getDate() {
        return this.date;
    }
    
    public void setDate(Date date) {
        this.date = date;
    }

    @Column(name="days", nullable=false)
    public Integer getDays() {
        return days;
    }

    public void setDays(Integer days) {
        this.days = days;
    }

    
    @Column(name="price",nullable=false, precision=22, scale=0)
    public double getPrice() {
        return this.price;
    }
    
    public void setPrice(double price) {
        this.price = price;
    }
    @Column(name="subtotal", nullable=false, precision=22, scale=0)
    public double getSubtotal() {
        return this.subtotal;
    }
    
    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    @Column(name="ststus",nullable=false, length=45)
    public String getStstus() {
        return ststus;
    }

    public void setStstus(String ststus) {
        this.ststus = ststus;
    }

    @Column(name="custid", nullable=false)
    public Integer getCustid() {
        return custid;
    }

    public void setCustid(Integer custid) {
        this.custid = custid;
    }

    



}
