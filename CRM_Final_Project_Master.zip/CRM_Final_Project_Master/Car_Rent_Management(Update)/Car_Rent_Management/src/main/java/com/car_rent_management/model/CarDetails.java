/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 *
 * @author HASAN
 */
@Entity
public class CarDetails implements java.io.Serializable{
    
     private int carid;
     private int catid;
     private String brand;
     private double rantprice;
     private String image;
     private String colour;
     private String fuel;
     private String mileage;
     private String carcategory;
     private boolean status;

    public CarDetails() {
    }

    public CarDetails(int carid, int catid, String brand, double rantprice, String image, String colour, String fuel, String mileage, String carcategory, boolean status) {
       this.carid = carid;
       this.catid = catid;
       this.brand = brand;
       this.rantprice = rantprice;
       this.image = image;
       this.colour = colour;
       this.fuel = fuel;
       this.mileage = mileage;
       this.carcategory = carcategory;
       this.status = status;
    }
   
     @Id 

    
    @Column(name="carid", unique=true, nullable=false)
    public int getCarid() {
        return this.carid;
    }
    
    public void setCarid(int carid) {
        this.carid = carid;
    }

    
    @Column(name="catid", nullable=false)
    public int getCatid() {
        return this.catid;
    }
    
    public void setCatid(int catid) {
        this.catid = catid;
    }

    
    @Column(name="brand", nullable=false, length=45)
    public String getBrand() {
        return this.brand;
    }
    
    public void setBrand(String brand) {
        this.brand = brand;
    }

    
    @Column(name="rantprice", nullable=false, precision=22, scale=0)
    public double getRantprice() {
        return this.rantprice;
    }
    
    public void setRantprice(double rantprice) {
        this.rantprice = rantprice;
    }

    
    @Column(name="image", nullable=false, length=45)
    public String getImage() {
        return this.image;
    }
    
    public void setImage(String image) {
        this.image = image;
    }

    
    @Column(name="colour", nullable=false, length=45)
    public String getColour() {
        return this.colour;
    }
    
    public void setColour(String colour) {
        this.colour = colour;
    }

    
    @Column(name="fuel", nullable=false, length=45)
    public String getFuel() {
        return this.fuel;
    }
    
    public void setFuel(String fuel) {
        this.fuel = fuel;
    }

    
    @Column(name="mileage", nullable=false, length=45)
    public String getMileage() {
        return this.mileage;
    }
    
    public void setMileage(String mileage) {
        this.mileage = mileage;
    }

    
    @Column(name="carcategory", nullable=false, length=45)
    public String getCarcategory() {
        return this.carcategory;
    }
    
    public void setCarcategory(String carcategory) {
        this.carcategory = carcategory;
    }

    
    @Column(name="status", nullable=false)
    public boolean isStatus() {
        return this.status;
    }
    
    public void setStatus(boolean status) {
        this.status = status;
    }
    
}
