/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 *
 * @author HASAN
 */
@Entity
public class CarDriver implements java.io.Serializable{
    private int driverid;
     private String name;
     private String address;
     private String phone;
     private String email;
     private String licenseno;
     private String expyear;
     private String location;
     private boolean status;

    public CarDriver() {
    }

    public CarDriver(int driverid, String name, String address, String phone, String email, String licenseno, String expyear, String location, boolean status) {
       this.driverid = driverid;
       this.name = name;
       this.address = address;
       this.phone = phone;
       this.email = email;
       this.licenseno = licenseno;
       this.expyear = expyear;
       this.location = location;
       this.status = status;
    }
   
     @Id 

    
    @Column(name="driverid", unique=true, nullable=false)
    public int getDriverid() {
        return this.driverid;
    }
    
    public void setDriverid(int driverid) {
        this.driverid = driverid;
    }

    
    @Column(name="name", nullable=false, length=45)
    public String getName() {
        return this.name;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    
    @Column(name="address", nullable=false, length=45)
    public String getAddress() {
        return this.address;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }

    
    @Column(name="phone", nullable=false, length=45)
    public String getPhone() {
        return this.phone;
    }
    
    public void setPhone(String phone) {
        this.phone = phone;
    }

    
    @Column(name="email", nullable=false, length=45)
    public String getEmail() {
        return this.email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }

    
    @Column(name="licenseno", nullable=false, length=45)
    public String getLicenseno() {
        return this.licenseno;
    }
    
    public void setLicenseno(String licenseno) {
        this.licenseno = licenseno;
    }

    
    @Column(name="expyear", nullable=false, length=45)
    public String getExpyear() {
        return this.expyear;
    }
    
    public void setExpyear(String expyear) {
        this.expyear = expyear;
    }

    
    @Column(name="location", nullable=false, length=45)
    public String getLocation() {
        return this.location;
    }
    
    public void setLocation(String location) {
        this.location = location;
    }

    
    @Column(name="status", nullable=false)
    public boolean isStatus() {
        return this.status;
    }
    
    public void setStatus(boolean status) {
        this.status = status;
    }
}
