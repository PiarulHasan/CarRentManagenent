/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author HASAN
 */
@Entity
public class Carcompany implements java.io.Serializable{
    
     private int companyid;
     private String catid;
     private String name;
     private String address;
     private String phone;
     private double price;
     private String email;
     private Date date;

    public Carcompany() {
    }

    public Carcompany(int companyid, String catid, String name, String address, String phone, double price, String email, Date date) {
       this.companyid = companyid;
       this.catid = catid;
       this.name = name;
       this.address = address;
       this.phone = phone;
       this.price = price;
       this.email = email;
       this.date = date;
    }
   
     @Id 

    
    @Column(name="companyid", unique=true, nullable=false)
    public int getCompanyid() {
        return this.companyid;
    }
    
    public void setCompanyid(int companyid) {
        this.companyid = companyid;
    }

    
    @Column(name="catid", nullable=false, length=45)
    public String getCatid() {
        return this.catid;
    }
    
    public void setCatid(String catid) {
        this.catid = catid;
    }

    
    @Column(name="name", nullable=false, length=45)
    public String getName() {
        return this.name;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    
    @Column(name="address", nullable=false, length=45)
    public String getAddress() {
        return this.address;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }

    
    @Column(name="phone", nullable=false, length=45)
    public String getPhone() {
        return this.phone;
    }
    
    public void setPhone(String phone) {
        this.phone = phone;
    }

    
    @Column(name="price", nullable=false, precision=22, scale=0)
    public double getPrice() {
        return this.price;
    }
    
    public void setPrice(double price) {
        this.price = price;
    }

    
    @Column(name="email", nullable=false, length=45)
    public String getEmail() {
        return this.email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }

    @Temporal(TemporalType.DATE)
    @Column(name="date", nullable=false, length=19)
    public Date getDate() {
        return this.date;
    }
    
    public void setDate(Date date) {
        this.date = date;
    }
    
}
