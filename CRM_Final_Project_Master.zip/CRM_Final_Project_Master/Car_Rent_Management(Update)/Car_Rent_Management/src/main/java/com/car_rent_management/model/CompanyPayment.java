/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author HASAN
 */
@Entity
public class CompanyPayment implements java.io.Serializable{
   private int paymentid;
     private int companyid;
     private double payamount;
     private Date date;

    public CompanyPayment() {
    }

    public CompanyPayment(int paymentid, int companyid, double payamount, Date date) {
       this.paymentid = paymentid;
       this.companyid = companyid;
       this.payamount = payamount;
       this.date = date;
    }
   
     @Id 

    
    @Column(name="paymentid", unique=true, nullable=false)
    public int getPaymentid() {
        return this.paymentid;
    }
    
    public void setPaymentid(int paymentid) {
        this.paymentid = paymentid;
    }

    
    @Column(name="companyid", nullable=false)
    public int getCompanyid() {
        return this.companyid;
    }
    
    public void setCompanyid(int companyid) {
        this.companyid = companyid;
    }

    
    @Column(name="payamount", nullable=false, precision=22, scale=0)
    public double getPayamount() {
        return this.payamount;
    }
    
    public void setPayamount(double payamount) {
        this.payamount = payamount;
    }

    @Temporal(TemporalType.DATE)
    @Column(name="date", nullable=false, length=19)
    public Date getDate() {
        return this.date;
    }
    
    public void setDate(Date date) {
        this.date = date;
    } 
}
