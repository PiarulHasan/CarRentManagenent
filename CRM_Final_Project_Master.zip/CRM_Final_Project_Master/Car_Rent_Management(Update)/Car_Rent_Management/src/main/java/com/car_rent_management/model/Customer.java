/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;

/**
 *
 * @author kawsar
 */
@Entity
public class Customer  implements java.io.Serializable {


     private Integer custid;
     private String custname;
     private String address;
     private String phone;
     private String email;
     private String location;

    public Customer() {
    }

    public Customer(String custname, String address, String phone, String email, String location) {
       this.custname = custname;
       this.address = address;
       this.phone = phone;
       this.email = email;
       this.location = location;
    }
   
    @Column(name="custid", unique=true, nullable=false)
     @Id
    @GeneratedValue(strategy=IDENTITY)
    public Integer getCustid() {
        return this.custid;
    }
    
    public void setCustid(Integer custid) {
        this.custid = custid;
    }
    @Column(name="custname",nullable=false, length=45)
    public String getCustname() {
        return this.custname;
    }
    
    public void setCustname(String custname) {
        this.custname = custname;
    }
    @Column(name="address",nullable=false, length=45)
    public String getAddress() {
        return this.address;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }
    @Column(name="phone",nullable=false, length=45)
    public String getPhone() {
        return this.phone;
    }
    
    public void setPhone(String phone) {
        this.phone = phone;
    }
    @Column(name="email",nullable=false, length=45)
    public String getEmail() {
        return this.email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    @Column(name="location",nullable=false, length=45)
    public String getLocation() {
        return this.location;
    }
    
    public void setLocation(String location) {
        this.location = location;
    }




}
