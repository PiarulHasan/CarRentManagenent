/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.model;

/**
 *
 * @author kawsar
 */
public class Demo {
    String Carname;

    public String getCarname() {
        return Carname;
    }

    public void setCarname(String Carname) {
        this.Carname = Carname;
    }

    

    
    
    
    
}
