/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author HASAN
 */
@Entity
public class DriverPayment implements java.io.Serializable{
    private int paymentid;
     private int driverid;
     private double payamount;
     private Date date;

    public DriverPayment() {
    }

    public DriverPayment(int paymentid, int driverid, double payamount, Date date) {
       this.paymentid = paymentid;
       this.driverid = driverid;
       this.payamount = payamount;
       this.date = date;
    }
   
     @Id 

    
    @Column(name="paymentid", unique=true, nullable=false)
    public int getPaymentid() {
        return this.paymentid;
    }
    
    public void setPaymentid(int paymentid) {
        this.paymentid = paymentid;
    }

    
    @Column(name="driverid", nullable=false)
    public int getDriverid() {
        return this.driverid;
    }
    
    public void setDriverid(int driverid) {
        this.driverid = driverid;
    }

    
    @Column(name="payamount", nullable=false, precision=22, scale=0)
    public double getPayamount() {
        return this.payamount;
    }
    
    public void setPayamount(double payamount) {
        this.payamount = payamount;
    }

    @Temporal(TemporalType.DATE)
    @Column(name="date", nullable=false, length=19)
    public Date getDate() {
        return this.date;
    }
    
    public void setDate(Date date) {
        this.date = date;
    }
}
