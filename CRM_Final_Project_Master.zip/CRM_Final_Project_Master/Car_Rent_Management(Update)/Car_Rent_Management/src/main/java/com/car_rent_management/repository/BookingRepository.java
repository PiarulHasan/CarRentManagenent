/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.repository;

import com.car_rent_management.model.Booking;
import com.car_rent_management.service.BookingService;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author kawsar
 */
@Repository
public class BookingRepository implements BookingService{
    @Autowired
    SessionFactory sessionFactory;
    
    public List<Booking> viewAllBooking() {
        
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        List<Booking> bookinglist = session.createQuery("from Booking").list();
        transaction.commit();
        session.close();
        
        return bookinglist;
    }
    @Override
    public List<Booking> viewAllBookingCarname() {
       Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        List<Booking> bookinglist = session.createQuery("select b.carname from Booking b").list();
        transaction.commit();
        session.close();
        
        return bookinglist; 
    }
    
    @Override
    public Booking viewOneBooking(int bookingid) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        Booking booking = (Booking)session.get(Booking.class, bookingid);
        transaction.commit();
        session.close();
        
        return booking;
    }

    @Override
    public Booking viewBookingByCarname(String carname) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        Criteria crit = session.createCriteria(Booking.class);
        crit.add(Restrictions.eq("carname", carname));
        Booking booking = (Booking)crit.uniqueResult();
        transaction.commit();
        session.close();
        
        return booking;
    }

    @Override
    public Booking insertBooking(Booking Booking) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        session.save(Booking);
        transaction.commit();
        session.close();
        
        return Booking;
    }

    @Override
    public void updateBooking(Booking Booking) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        session.update(Booking);
        transaction.commit();
        session.close();
    }

    @Override
    public void deleteBooking(int bookingid) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        Booking Booking = (Booking)session.get(Booking.class, bookingid);
        session.delete(Booking);
        transaction.commit();
        session.close();
    
    
}
}
