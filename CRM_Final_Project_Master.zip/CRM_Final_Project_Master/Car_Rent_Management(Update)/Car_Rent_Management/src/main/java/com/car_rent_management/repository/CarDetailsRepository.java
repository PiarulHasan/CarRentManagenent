/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.repository;

import com.car_rent_management.model.CarDetails;
import com.car_rent_management.service.CarDetailsService;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author kawsar
 */
@Repository
public class CarDetailsRepository implements CarDetailsService{
    
    @Autowired
    SessionFactory sessionFactory;

    @Override
    public List<CarDetails> viewAllCarDetails() {
        
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        List<CarDetails> carDetailslist = session.createQuery("from CarDetails").list();
        transaction.commit();
        session.close();
        
        return carDetailslist;
    }

    @Override
    public List<CarDetails> viewAllCarDetailsBrand() {
       Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        List<CarDetails> carDetailslist = session.createQuery("select c.brand from CarDetails c").list();
        transaction.commit();
        session.close();
        
        return carDetailslist; 
    }

    @Override
    public CarDetails viewOneCarDetails(int carid) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        CarDetails carDetails = (CarDetails)session.get(CarDetails.class, carid);
        transaction.commit();
        session.close();
        
        return carDetails;
    }

    @Override
    public CarDetails viewCardetailsByBrand(String brand) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        Criteria crit = session.createCriteria(CarDetails.class);
        crit.add(Restrictions.eq("brand", brand));
        CarDetails carDetails = (CarDetails)crit.uniqueResult();
        transaction.commit();
        session.close();
        
        return carDetails;
    }

    @Override
    public CarDetails insertCardetails(CarDetails CarDetails) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        session.save(CarDetails);
        transaction.commit();
        session.close();
        
        return CarDetails;
    }

    @Override
    public void updateCardetails(CarDetails CarDetails) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        session.update(CarDetails);
        transaction.commit();
        session.close();
    }

    @Override
    public void deleteCardetails(int carid) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        CarDetails CarDetails = (CarDetails)session.get(CarDetails.class, carid);
        session.delete(CarDetails);
        transaction.commit();
        session.close();
    }

    

    
    
}
