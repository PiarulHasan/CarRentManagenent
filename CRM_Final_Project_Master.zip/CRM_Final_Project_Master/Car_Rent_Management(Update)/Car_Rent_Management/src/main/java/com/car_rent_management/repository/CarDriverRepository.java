/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.repository;

import com.car_rent_management.model.CarDriver;
import com.car_rent_management.service.CarDriverService;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author HASAN
 */
@Repository
public class CarDriverRepository implements CarDriverService{
    
    @Autowired
    SessionFactory sessionFactory;

    @Override
    public List<CarDriver> viewAllCarDriver() {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        List<CarDriver> carDriverlist = session.createQuery("from CarDriver").list();
        transaction.commit();
        session.close();
        
        return carDriverlist;
    }

    @Override
    public List<CarDriver> viewAllCarDriverName() {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        List<CarDriver> carDriverlist = session.createQuery("select c.name from CarDriver c").list();
        transaction.commit();
        session.close();
        
        return carDriverlist;
    }

    @Override
    public CarDriver viewOneCarDriver(int driverid) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        CarDriver carDriver = (CarDriver)session.get(CarDriver.class, driverid);
        transaction.commit();
        session.close();
        
        return carDriver; 
    }

    @Override
    public CarDriver viewCarDriverByName(String name) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        Criteria crit = session.createCriteria(CarDriver.class);
        crit.add(Restrictions.eq("name", name));
        CarDriver carDriver = (CarDriver)crit.uniqueResult();
        transaction.commit();
        session.close();
        
        return carDriver;
    }

    @Override
    public CarDriver insertCarDriver(CarDriver CarDriver) {
       Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        session.save(CarDriver);
        transaction.commit();
        session.close();
        
        return CarDriver; 
    }

    @Override
    public void updateCarDriver(CarDriver CarDriver) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        session.update(CarDriver);
        transaction.commit();
        session.close();
    }

    @Override
    public void deleteCarDriver(int driverid) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        CarDriver CarDriver = (CarDriver)session.get(CarDriver.class, driverid);
        session.delete(CarDriver);
        transaction.commit();
        session.close();  
    }
    
}
