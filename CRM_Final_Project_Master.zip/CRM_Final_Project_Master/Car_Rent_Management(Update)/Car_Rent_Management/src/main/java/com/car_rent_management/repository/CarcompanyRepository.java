/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.repository;

import com.car_rent_management.model.Carcompany;
import com.car_rent_management.service.CarcompanyService;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author HASAN
 */
@Repository
public class CarcompanyRepository implements CarcompanyService{

    @Autowired
    SessionFactory sessionFactory;
    
    
    @Override
    public List<Carcompany> viewAllCarcompany() {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        List<Carcompany> carcompanylist = session.createQuery("from Carcompany").list();
        transaction.commit();
        session.close();
        
        return carcompanylist;        
 
    }

    @Override
    public Carcompany viewOneCarcompany(int companyid) {
       Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        Carcompany carcompany = (Carcompany)session.get(Carcompany.class, companyid);
        transaction.commit();
        session.close();
        
        return carcompany; 
    }



    @Override
    public Carcompany insertCarcompany(Carcompany Carcompany) {
     Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        session.save(Carcompany);
        transaction.commit();
        session.close();
        
        return Carcompany;   
    }

    @Override
    public void updateCarcompany(Carcompany Carcompany) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        session.update(Carcompany);
        transaction.commit();
        session.close();
    }

    @Override
    public void deleteCarcompany(int companyid) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        Carcompany Carcompany = (Carcompany)session.get(Carcompany.class, companyid);
        session.delete(Carcompany);
        transaction.commit();
        session.close();
    }

    @Override
    public List<Carcompany> viewAllCarcompanyName() {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        List<Carcompany> carcompanylist = session.createQuery("select c.name from carcompany c").list();
        transaction.commit();
        session.close();
        
        return carcompanylist;
    }

    @Override
    public Carcompany viewCarcompanyByName(String name) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        Criteria crit = session.createCriteria(Carcompany.class);
        crit.add(Restrictions.eq("name", name));
        Carcompany carcompany = (Carcompany)crit.uniqueResult();
        transaction.commit();
        session.close();
        
        return carcompany;
    }

  
    
}
