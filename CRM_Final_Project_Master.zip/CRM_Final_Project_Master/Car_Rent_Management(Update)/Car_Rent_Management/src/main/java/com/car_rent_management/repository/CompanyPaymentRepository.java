/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.repository;

import com.car_rent_management.model.CompanyPayment;
import com.car_rent_management.service.CompanyPaymentService;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author HASAN
 */
@Repository
public class CompanyPaymentRepository implements CompanyPaymentService{
    @Autowired
    SessionFactory sessionFactory;

    @Override
    public List<CompanyPayment> viewAllCompanyPayment() {
       Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        List<CompanyPayment> companyPaymentlist = session.createQuery("from CompanyPayment").list();
        transaction.commit();
        session.close();
        
        return companyPaymentlist; 
    }

    @Override
    public CompanyPayment viewOneCompanyPayment(int paymentid) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        CompanyPayment companyPayment = (CompanyPayment)session.get(CompanyPayment.class, paymentid);
        transaction.commit();
        session.close();
        
        return companyPayment;
    }

    @Override
    public CompanyPayment insertCompanyPayment(CompanyPayment CompanyPayment) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        session.save(CompanyPayment);
        transaction.commit();
        session.close();
        
        return CompanyPayment;
    }

    @Override
    public void updateCompanyPayment(CompanyPayment CompanyPayment) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        session.update(CompanyPayment);
        transaction.commit();
        session.close();
    }

    @Override
    public void deleteCompanyPayment(int paymentid) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        CompanyPayment CompanyPayment = (CompanyPayment)session.get(CompanyPayment.class, paymentid);
        session.delete(CompanyPayment);
        transaction.commit();
        session.close();
    }
    
}
