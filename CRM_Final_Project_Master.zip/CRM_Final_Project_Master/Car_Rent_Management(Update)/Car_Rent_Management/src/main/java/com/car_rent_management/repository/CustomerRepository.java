/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.repository;

import com.car_rent_management.model.Customer;
import com.car_rent_management.service.CustomerService;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author kawsar
 */
@Repository
public class CustomerRepository implements CustomerService{
    @Autowired
    SessionFactory sessionFactory;
    
    @Override
    public List<Customer> viewAllCustomer() {
        
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        List<Customer> customerlist = session.createQuery("from Customer").list();
        transaction.commit();
        session.close();
        
        return customerlist;
    }
    @Override
    public List<Customer> viewAllCustomerCustname() {
       Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        List<Customer> customerlist = session.createQuery("select c.custname from Customer c").list();
        transaction.commit();
        session.close();
        
        return customerlist; 
    }
    
    @Override
    public Customer viewOneCustomer(int custid) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        Customer customer = (Customer)session.get(Customer.class, custid);
        transaction.commit();
        session.close();
        
        return customer;
    }

    @Override
    public Customer viewCustomerByCustname(String custname) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        Criteria crit = session.createCriteria(Customer.class);
        crit.add(Restrictions.eq("custname", custname));
        Customer customer = (Customer)crit.uniqueResult();
        transaction.commit();
        session.close();
        
        return customer;
    }

    @Override
    public Customer insertCustomer(Customer Customer) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        session.save(Customer);
        transaction.commit();
        session.close();
        
        return Customer;
    }

    @Override
    public void updateCustomer(Customer Customer) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        session.update(Customer);
        transaction.commit();
        session.close();
    }

    @Override
    public void deleteCustomer(int custid) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        Customer Customer = (Customer)session.get(Customer.class, custid);
        session.delete(Customer);
        transaction.commit();
        session.close();
    
    
}
    
}
