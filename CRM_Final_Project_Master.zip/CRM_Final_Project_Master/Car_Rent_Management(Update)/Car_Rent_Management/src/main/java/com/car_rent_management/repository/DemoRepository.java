/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;

/**
 *
 * @author kawsar
 */
public class DemoRepository {
    public Connection getConnection() throws SQLException {
        Connection conn = null;

        try {

            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Please include Classpath Where your MySQL Driver is located");
            e.printStackTrace();
        }

        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/car_rent", "root", "123");

        if (conn != null) {
            System.out.println("Database Connected");
        } else {
            System.out.println(" connection Failed ");
        }

        return conn;

    }
    
    
    
    public JasperPrint getCompiledFile(String fileName, HashMap<String, Object> hmParams, HttpServletRequest request) throws Exception {
        System.out.println("path " + request.getSession().getServletContext().getRealPath("/report/" + fileName + ".jasper"));
        
        String path =  request.getSession().getServletContext().getRealPath("/report/" + fileName + ".jasper");
            
        
        return JasperFillManager.fillReport(path, hmParams, getConnection());
         
    }
    
}
