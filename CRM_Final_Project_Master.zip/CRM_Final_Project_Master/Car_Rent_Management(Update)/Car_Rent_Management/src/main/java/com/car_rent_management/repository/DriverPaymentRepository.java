/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.repository;

import com.car_rent_management.model.DriverPayment;
import com.car_rent_management.service.DriverPaymentService;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author HASAN
 */
@Repository
public class DriverPaymentRepository implements DriverPaymentService{
    
    @Autowired
    SessionFactory sessionFactory;

    @Override
    public List<DriverPayment> viewAllDriverPayment() {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        List<DriverPayment> driverPaymentlist = session.createQuery("from DriverPayment").list();
        transaction.commit();
        session.close();
        
        return driverPaymentlist;
    }

    @Override
    public DriverPayment viewOneDriverPayment(int paymentid) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        DriverPayment driverPayment = (DriverPayment)session.get(DriverPayment.class, paymentid);
        transaction.commit();
        session.close();
        
        return driverPayment;
    }

    @Override
    public DriverPayment insertDriverPayment(DriverPayment DriverPayment) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        session.save(DriverPayment);
        transaction.commit();
        session.close();
        
        return DriverPayment;
    }

    @Override
    public void updateDriverPayment(DriverPayment DriverPayment) {
      Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        session.update(DriverPayment);
        transaction.commit();
        session.close();  
    }

    @Override
    public void deleteDriverPayment(int paymentid) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        DriverPayment DriverPayment = (DriverPayment)session.get(DriverPayment.class, paymentid);
        session.delete(DriverPayment);
        transaction.commit();
        session.close();
    }
    
}
