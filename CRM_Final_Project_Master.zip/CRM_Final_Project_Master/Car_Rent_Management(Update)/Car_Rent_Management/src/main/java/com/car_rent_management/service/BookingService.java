/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.service;

import com.car_rent_management.model.Booking;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author kawsar
 */
@Service
public interface BookingService {
    public List<Booking> viewAllBooking();
    
    public List<Booking> viewAllBookingCarname();
    
    public Booking viewOneBooking(int bookingid);
    
    public Booking viewBookingByCarname(String carname);
    
    public Booking insertBooking(Booking Booking);
    
    public void updateBooking(Booking Booking);
    
    public void deleteBooking(int bookingid);
    
}
