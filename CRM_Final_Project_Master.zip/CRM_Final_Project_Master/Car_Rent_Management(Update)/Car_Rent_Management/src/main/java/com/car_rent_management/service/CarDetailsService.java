/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.service;

import com.car_rent_management.model.CarDetails;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author kawsar
 */
@Service
public interface CarDetailsService {
    
    public List<CarDetails> viewAllCarDetails();
    
    public List<CarDetails> viewAllCarDetailsBrand();
    
    public CarDetails viewOneCarDetails(int carid);
    
    public CarDetails viewCardetailsByBrand(String name);
    
    public CarDetails insertCardetails(CarDetails CarDetails);
    
    public void updateCardetails(CarDetails CarDetails);
    
    public void deleteCardetails(int carid);
}
