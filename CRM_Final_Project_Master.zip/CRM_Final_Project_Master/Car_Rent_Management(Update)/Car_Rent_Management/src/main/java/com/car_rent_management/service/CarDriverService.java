/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.service;

import com.car_rent_management.model.CarDriver;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author HASAN
 */
@Service
public interface CarDriverService {
    public List<CarDriver> viewAllCarDriver();
    
    public List<CarDriver> viewAllCarDriverName();
    
    public CarDriver viewOneCarDriver(int driverid);
    
    public CarDriver viewCarDriverByName(String name);
    
    public CarDriver insertCarDriver(CarDriver CarDriver);
    
    public void updateCarDriver(CarDriver CarDriver);
    
    public void deleteCarDriver(int driverid);
}
