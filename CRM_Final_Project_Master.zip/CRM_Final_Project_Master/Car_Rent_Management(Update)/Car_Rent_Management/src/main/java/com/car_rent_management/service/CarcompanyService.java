/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.service;

import com.car_rent_management.model.Carcompany;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author HASAN
 */
@Service
public interface CarcompanyService {
    public List<Carcompany> viewAllCarcompany();
    
    public List<Carcompany> viewAllCarcompanyName();
    
    public Carcompany viewOneCarcompany(int companyid);
    
    public Carcompany viewCarcompanyByName(String name);
    
    public Carcompany insertCarcompany(Carcompany Carcompany);
    
    public void updateCarcompany(Carcompany Carcompany);
    
    public void deleteCarcompany(int companyid);
}
