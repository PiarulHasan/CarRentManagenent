/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.service;

import com.car_rent_management.model.Category;
import org.springframework.stereotype.Service;

/**
 *
 * @author HASAN
 */
@Service
public interface CategoryService {
    public String insertCategory(Category cm);

    public String updateCategory(Category cm);

    public String deleteCategory(String id);

    public String viewCategory();

    public Category viewOneCategory(String id);
    
}
