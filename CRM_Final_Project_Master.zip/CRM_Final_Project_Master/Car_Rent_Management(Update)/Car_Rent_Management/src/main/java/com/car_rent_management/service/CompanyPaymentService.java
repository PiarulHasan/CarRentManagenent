/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.service;

import com.car_rent_management.model.CompanyPayment;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author HASAN
 */
@Service
public interface CompanyPaymentService {
    public List<CompanyPayment> viewAllCompanyPayment();
    
//    public List<CompanyPayment> viewAllCompanyPaymentName();
    
    public CompanyPayment viewOneCompanyPayment(int paymentid);
    
//    public CompanyPayment viewCompanyPaymentByName(String name);
    
    public CompanyPayment insertCompanyPayment(CompanyPayment CompanyPayment);
    
    public void updateCompanyPayment(CompanyPayment CompanyPayment);
    
    public void deleteCompanyPayment(int paymentid);
}
