/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.service;

import com.car_rent_management.model.Customer;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author kawsar
 */
@Service
public interface CustomerService {
    public List<Customer> viewAllCustomer();
    
    public List<Customer> viewAllCustomerCustname();
    
    public Customer viewOneCustomer(int custid);
    
    public Customer viewCustomerByCustname(String name);
    
    public Customer insertCustomer(Customer Customer);
    
    public void updateCustomer(Customer Customer);
    
    public void deleteCustomer(int custid);
    
}
