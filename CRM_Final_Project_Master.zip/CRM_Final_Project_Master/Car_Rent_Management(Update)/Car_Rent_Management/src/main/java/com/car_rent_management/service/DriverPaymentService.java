/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.car_rent_management.service;

import com.car_rent_management.model.DriverPayment;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author HASAN
 */
@Service
public interface DriverPaymentService {
    public List<DriverPayment> viewAllDriverPayment();
    
//    public List<DriverPayment> viewAllCompanyPaymentName();
    
    public DriverPayment viewOneDriverPayment(int paymentid);
    
//    public DriverPayment viewCompanyPaymentByName(String name);
    
    public DriverPayment insertDriverPayment(DriverPayment DriverPayment);
    
    public void updateDriverPayment(DriverPayment DriverPayment);
    
    public void deleteDriverPayment(int paymentid);
    
}
